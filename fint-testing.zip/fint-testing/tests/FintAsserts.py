import os
import secrets
import string
import yaml
from pytest_html import extras
import pandas as pd
import logging

from database_comparator.DataBaseUtil import execute_query, compare_results

limit = 10000000
report_format = ".html"
batchkey = "&batchkey"
psiclebatchkey = "&psiclebatchkey"
order_by_offset = " order by 1 offset "
log = logging.getLogger()
count_query = "select count(*) from ("
sub_query = ") as subquery"


def color_fail_red(val):
    """
    apply style to a dataframe, to differentiate failed data
    :param val: vaue in a cell, that has to be marked pass/fail
    :return: style object
    """
    if val == 'False':
        color = 'orange'
    elif val == 'True':
        color = 'green'
    else:
        color = 'white'
    return 'background-color: %s' % color


def color_fail_nan(val):
    """
    apply style to a dataframe, to differentiate failed data
    :param val: vaue in a cell, that has to be marked pass/fail
    :return: style object
    """
    if val == 'nan':
        color = 'orange'
    else:
        color = 'white'
    return 'background-color: %s' % color


def add_caption():
    """
    add caption to the dataframes
    :return:
    """
    return [{
        'selector': 'caption',
        'props': [
            ('color', 'grey'),
            ('font-size', '16px')
        ]
    }]


def generate_report(errors, report_dir, extra, report_filename):
    """
    method to generate html report for the data contract testing
    :param errors: a dataframe of dictionaries containing error count andfew sample error data
    :param report_dir: dir where report will be generated
    :param extra: pytest html extra object
    :param report_filename: name of the html report
    :return: None
    """
    report_dir = report_dir + '/log'
    if not os.path.exists(report_dir):
        os.makedirs(report_dir)
    records = {'errors': [], 'count': []}
    for x in range(0, len(errors)):
        if str(errors[x].get('count')) != '0':
            random_char = ''.join(secrets.choice(string.ascii_lowercase) for _ in range(6))
            filename = report_dir + '/' + random_char + report_filename + str(x) + errors[x].get('dataframe').columns[0] \
                       + "_" + str(x) + report_format
            records['errors'].append('Number of ' + errors[x].get('dataframe').columns[0])
            records['count'].append(
                write_report(errors[x].get('dataframe'), filename, 'first few errors', str(errors[x].get('count'))))
    records_df = pd.DataFrame(data=records)
    extra.append(extras.html(records_df.style.set_table_styles(get_styles()).applymap(color_fail_red).render()))


def generate_mapping_report(matched_records, missing_records, mismatch_records, report_dir, extra):
    """
    method to generate report for the mapping queries tests
    :param matched_records: a dataframe containing the matched records
    :param missing_records: a dataframe containing the missing records
    :param mismatch_records: a dataframe containing the mismatch records
    :param report_dir: dir where report will be generated
    :param extra: pytest html extra object
    :return: None
    """
    report_dir = report_dir + '/log'
    if not os.path.exists(report_dir):
        os.makedirs(report_dir)
    random_char = ''.join(secrets.choice(string.ascii_lowercase) for _ in range(6))
    missing_records_filename = report_dir + '/' + random_char + 'missing_records' + report_format
    mismatch_records_filename = report_dir + '/' + random_char + 'mismatch_records' + report_format
    matched_records_filename = report_dir + '/' + random_char + 'matched_records' + report_format
    records = {'record_name': ['Number of missing records', 'Number of mismatch records', 'Number of matched records'],
               'count': [write_report(missing_records, missing_records_filename, 'missing records',
                                      str(len(missing_records))),
                         write_report(mismatch_records, mismatch_records_filename, 'mismatch records',
                                      str(len(mismatch_records))),
                         write_report(matched_records, matched_records_filename, 'matched records',
                                      str(len(matched_records)))]}
    records_df = pd.DataFrame(data=records)
    extra.append(extras.html(records_df.style.set_table_styles(get_styles()).applymap(color_fail_red).render()))


def generate_singlequery_report(false_records, true_records, report_dir, extra):
    """
    method to generate report for the single queries tests
    :param false_records: a dataframe containing the false records
    :param report_dir: dir where report will be generated
    :param extra: pytest html extra object
    :return: None
    """
    report_format = ".html"
    report_dir = report_dir + '/log'
    if not os.path.exists(report_dir):
        os.makedirs(report_dir)
    random_char = ''.join(secrets.choice(string.ascii_lowercase) for _ in range(6))
    false_records_filename = report_dir + '/' + random_char + 'false_records' + report_format
    true_records_filename = report_dir + '/' + random_char + 'true_records' + report_format
    records = {'record_name': ['Number of failed records', 'Number of passed records'],
               'count': [write_report(false_records, false_records_filename, 'false records',
                                      str(len(false_records))),
                         write_report(true_records, true_records_filename, 'true records',
                                      str(len(true_records)))
                         ]}
    records_df = pd.DataFrame(data=records)
    extra.append(extras.html(records_df.style.set_table_styles(get_styles()).applymap(color_fail_red).render()))


def write_report(record, filename, reportname, count):
    """
    method to write the html file and return the link to that html file
    :param record: a dataframe containing the records to write
    :param filename: html filename
    :param reportname: name of the record
    :param count: number of error
    :return: a link to the html file
    """
    with open(filename, mode='wt', encoding='utf-8') as file:
        file.write(record[:100].style.set_caption(reportname).set_table_styles(add_caption()).
                   set_table_styles(get_styles()).applymap(color_fail_red).render())
    return "<div><a href='./log/" + filename.split("/")[-1] + "' target='blank'>" + count + "</a></div>"


def mapping_test(scenario, extra, request):
    """
    method to test the mapping queries received from all integrations
    :param scenario: scenario object from the test
    :param extra: pytest html extra object from the test
    :param request: request object from the test
    :return: matched_records, missing_records, mismatch_records
    """
    global matched_records, missing_records, mismatch_records
    report_dir = request.config.getoption('reportfolder')
    exp_db = scenario['Scenario-id']['source']['configurations']['database']
    exp_query = scenario['Scenario-id']['source']['dataset']['query'].replace(batchkey,
                                                                              scenario['where_clause'])
    act_db = scenario['Scenario-id']['target']['configurations']['database']
    act_query = scenario['Scenario-id']['target']['dataset']['query'].replace(batchkey,
                                                                              scenario['where_clause'])
    exp_count_query = count_query + exp_query + sub_query
    exp_count = execute_query(exp_db, exp_count_query)['count'][0]
    log.debug("mapping expected query : " + exp_query)
    log.debug("mapping actual query : " + act_query)
    offset = 0
    matched_records_count = 0
    missing_records_count = 0
    mismatch_records_count = 0
    while offset < exp_count:
        offset_exp_query = exp_query + order_by_offset + str(offset) + " LIMIT " + str(limit)
        offset_act_query = act_query + order_by_offset + str(offset) + " LIMIT " + str(limit)
        exp_result = execute_query(exp_db, offset_exp_query).astype(str)
        act_result = execute_query(act_db, offset_act_query).astype(str)
        matched_records, missing_records, mismatch_records = compare_results(exp_result, act_result,
                                                                             scenario['Scenario-id']['source'],
                                                                             scenario['Scenario-id']['target'])
        matched_records_count = matched_records_count + len(matched_records)
        missing_records_count = missing_records_count + len(missing_records)
        mismatch_records_count = mismatch_records_count + len(mismatch_records)
        generate_mapping_report(matched_records, missing_records, mismatch_records, report_dir, extra)
        offset = offset + limit
    return matched_records_count, mismatch_records_count, missing_records_count


def psicle_mapping_test(scenario, extra, request):
    """
    method to test the mapping queries received from all integrations
    :param scenario: scenario object from the test
    :param extra: pytest html extra object from the test
    :param request: request object from the test
    :return: matched_records, missing_records, mismatch_records
    """
    global matched_records, missing_records, mismatch_records
    report_dir = request.config.getoption('reportfolder')
    expected_db = scenario['Scenario-id']['source']['configurations']['database']
    expected_query = scenario['Scenario-id']['source']['dataset']['query'].replace(batchkey,
                                                                              scenario['where_clause'])
    actual_db = scenario['Scenario-id']['target']['configurations']['database']
    actual_query = scenario['Scenario-id']['target']['dataset']['query'].replace(psiclebatchkey,
                                                                             os.getenv('psiclebatchkey'))
    expected_count_query = count_query + expected_query + sub_query
    expected_count = execute_query(expected_db, expected_count_query)['count'][0]
    log.debug("mapping expected query : " + expected_query)
    log.debug("mapping actual query : " + actual_query)
    offset = 0
    matched_records_count = 0
    missing_records_count = 0
    mismatch_records_count = 0
    while offset < expected_count:
        offset_exp_query = expected_query + order_by_offset + str(offset) + " LIMIT " + str(limit)
        offset_act_query = actual_query + order_by_offset + str(offset) + " LIMIT " + str(limit)
        exp_result = execute_query(expected_db, offset_exp_query).astype(str)
        act_result = execute_query(actual_db, offset_act_query).astype(str)
        matched_records, missing_records, mismatch_records = compare_results(exp_result, act_result,
                                                                             scenario['Scenario-id']['source'],
                                                                             scenario['Scenario-id']['target'])
        matched_records_count = matched_records_count + len(matched_records)
        missing_records_count = missing_records_count + len(missing_records)
        mismatch_records_count = mismatch_records_count + len(mismatch_records)
        generate_mapping_report(matched_records, missing_records, mismatch_records, report_dir, extra)
        offset = offset + limit
    return matched_records_count, mismatch_records_count, missing_records_count


def singlequery_test(scenario, extra, request):
    """
    method to test the mapping queries received from all integrations
    :param scenario: scenario object from the test
    :param extra: pytest html extra object from the test
    :param request: request object from the test
    :return: the count of false records
    """
    report_dir = request.config.getoption('reportfolder')
    exp_db = scenario['Scenario-id']['source']['configurations']['database']
    exp_query = scenario['Scenario-id']['source']['dataset']['query'].replace(batchkey,
                                                                              scenario['where_clause'])
    exp_count_query = count_query + exp_query + sub_query
    exp_count = execute_query(exp_db, exp_count_query)['count'][0]
    log.debug("singlequery expected query : " + exp_query)
    offset = 0
    false_count = 0
    records_count = 0
    while offset < exp_count:
        offset_exp_query = exp_query + order_by_offset + str(offset) + " LIMIT " + str(limit)
        exp_result = execute_query(exp_db, offset_exp_query)
        df = pd.DataFrame(exp_result)
        cols = pd.Series(df.columns)
        for dup in cols[cols.duplicated()].unique():
            cols[cols[cols == dup].index.values.tolist()] = [dup + '.' + str(i) if i != 0 else dup for
                                                             i in range(sum(cols == dup))]
        # rename the columns with the cols list to remove duplicated column names
        df.columns = cols
        false_count = false_count + len(df.loc[(df['true_false'] == 'false') | (df['true_false'] == 'False')])
        records_count = records_count + len(df)
        false_records = df.loc[(df['true_false'] == 'false') | (df['true_false'] == 'False')]
        true_records = df.loc[(df['true_false'] == 'true') | (df['true_false'] == 'True')]
        generate_singlequery_report(false_records,true_records, report_dir, extra)
        offset = offset + limit
    return false_count, records_count


def get_styles():
    """
    method that return a style object for the report
    :return: list of dictionaries containing css properties
    """
    table_props = [('font-family', '"Arial", Arial, sans-serif;'), ('font-size', '12pt;'),
                   ('border-collapse', 'collapse;'), ('padding', '0px;'), ('margin', '0px;'),
                   ('margin-bottom', '10pt;')]
    tbody_props = [('background', '#fff')]
    th_props = [('border', '0;'), ('text-align', 'center;'), ('padding', '0.5ex 1.5ex;'), ('margin',
                                                                                           '0px;')]
    # Set CSS properties for td elements in dataframe
    td_props = [('white-space', 'nowrap;'), ('border', '1;'), ('text-align', 'center;'), ('padding', '0.5ex 1.5ex;'),
                ('margin', '0px;')]
    tr_nthchild_props = [('background', '#fff')]
    thead_first = [('border-top', '2pt solid black;')]
    thead_last = [('border-bottom', '1pt solid black;')]
    tr_last = [('border-bottom', '2pt solid black;')]
    # Set table styles
    styles = [dict(selector="table", props=table_props),
              dict(selector="tbody", props=tbody_props),
              dict(selector="th", props=th_props),
              dict(selector="td", props=td_props),
              dict(selector="tbody tr:nth-child(odd)", props=tr_nthchild_props),
              dict(selector="thead>tr:first-child>th", props=thead_first),
              dict(selector="thead>tr:last-child>th", props=thead_last),
              dict(selector="tbody>tr:last-child>td", props=tr_last), ]
    return styles


def generate_tests(query, filename, total_scenarios, total_idlist, yaml_dir):
    """
    method to test the mapping queries received from all integrations
    :param query: query to identify the batchkeys received in last 24 hrs
    :param filename: yaml filenames to read to find tests
    :param total_scenarios: total number of scenarios identified from the file
    :param total_idlist: scenario name for scenarios identified
    :param yaml_dir: dir to traverse to find the scenarios
    :return: total scenarios and scenario IDs
    """
    batchkeys = execute_query(os.getenv("database"), query)
    # loop through number of files arrived
    for batchkey in batchkeys['batchkey']:
        for root, dirs, files in os.walk(yaml_dir):
            for file in files:
                # loop through mapping yaml files
                if file.endswith(filename):
                    with open(os.path.join(root, file)) as yaml_file:
                        currentscenarios = yaml.load(yaml_file, Loader=yaml.FullLoader)
                        # loop through the number of scenarios in yaml file
                        for scenario in currentscenarios['Scenarios']:
                            scenario['where_clause'] = '' + str(batchkey) + ''
                            total_idlist.append(
                                scenario['Scenario-id']['Scenario-Name'] + " BatchKey: " + str(batchkey))
                            total_scenarios['Scenarios'].append(scenario)
    return total_scenarios, total_idlist