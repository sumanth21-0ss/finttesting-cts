import os
from copy import deepcopy

import pytest
import yaml

from database_comparator.DataBaseUtil import execute_query
from database_comparator.DataContractUtil import validate_conditional_mandatory, validate_mandatory, \
    validate_mandatory_reference, validate_mandatory_redshift, validate_mandatory_reference_redshift
from tests.FintAsserts import generate_report

claim_report_format = ".html"
claim_url_prefix = "file://"


def pytest_generate_tests(metafunc):
    contracts_to_validate = []
    idlist = []
    with open(
            "tests/claims_accounting_integration/claims_datacontract_validation/psicle_data_contract.yaml") as file:
        yamlcontent = yaml.load(file, Loader=yaml.FullLoader)
        for contract in yamlcontent['psicle_data_contract']:
            batchkeys = execute_query(os.getenv("database"),
                                      "select distinct psiclebatchkey from fdp." + contract['contract'][
                                          'landing_table'] + " where psiclebatchkey in (" + os.getenv(
                                          'psiclebatchkeys') + ")")
            for batchkey in batchkeys['psiclebatchkey']:
                batch_contract = deepcopy(contract)
                batch_contract['contract']['batchkey'] = str(batchkey)
                contracts_to_validate.append(batch_contract)
                idlist.append(batch_contract['contract']['name'] + ' - ' + str(batchkey))
    metafunc.parametrize('contract', contracts_to_validate, ids=idlist)


def test_claims_conditional_mandatory_columns(contract, extra, request):
    with open(contract['contract']['schema']) as schemafile:
        yamlcontent = yaml.load(schemafile, Loader=yaml.FullLoader)
        if 'conditional_mandatory_columns' not in yamlcontent:
            pytest.skip('no conditional mandatory columns')
        conditional_mandatory_columns = yamlcontent['conditional_mandatory_columns']
    claim_report_dir = request.config.getoption('reportfolder')
    claims_errors = validate_conditional_mandatory(contract['contract']['landing_table'],
                                                   contract['contract']['batchkey'], conditional_mandatory_columns)
    generate_report(errors=claims_errors, report_dir=claim_report_dir, report_filename="claim_cond_mandatoryreportlog_",
                    extra=extra)
    if len(claims_errors) > 0:
        assert False
    else:
        assert True


def test_claims_mandatory_columns(contract, extra, request):
    with open(contract['contract']['schema']) as schemafile:
        yamlcontent = yaml.load(schemafile, Loader=yaml.FullLoader)
        mandatory_columns = yamlcontent['mandatory_columns']
    claim_report_dir = request.config.getoption('reportfolder')
    claims_errors = validate_mandatory_redshift(contract['contract']['landing_table'], contract['contract']['batchkey'],
                                       mandatory_columns)
    generate_report(errors=claims_errors, report_dir=claim_report_dir, report_filename="claim_mandatoryreportlog_",
                    extra=extra)
    if len(claims_errors) > 0:
        assert False
    else:
        assert True


def test_claims_mandatory_reference_data(contract, extra, request):
    with open(contract['contract']['schema']) as schemafile:
        yamlcontent = yaml.load(schemafile, Loader=yaml.FullLoader)
        if 'reference_columns' not in yamlcontent:
            pytest.skip('no reference columns')
        mandatory_reference_columns = yamlcontent['reference_columns']
    claim_report_dir = request.config.getoption('reportfolder')
    claims_errors = validate_mandatory_reference_redshift(contract['contract']['landing_table'],
                                                 contract['contract']['batchkey'], mandatory_reference_columns)
    generate_report(errors=claims_errors, report_dir=claim_report_dir, report_filename="claim_mandatoryreportlog_",
                    extra=extra)
    if len(claims_errors) > 0:
        assert False
    else:
        assert True
