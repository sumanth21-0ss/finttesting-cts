import collections
import os

from pytest_html import extras
from tests.FintAsserts import singlequery_test, generate_tests


def pytest_generate_tests(metafunc):
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    claims_yaml_files = 'tests/claims_accounting_integration/claims_sttm_validation'
    # generate test from LICAccounting Events mapping yaml
    total_scenarios, total_idlist = generate_tests(
        "select distinct psiclebatchkey as batchkey from fdp.f_psicleoutputamount where "
        "psiclebatchkey in ('" + os.getenv('batchkeys') + "')",
        "_singlequery.yaml", total_scenarios,
        total_idlist, claims_yaml_files)

    # generate test from LICAccounting_s02 Events mapping yaml
    total_scenarios, total_idlist = generate_tests(
        "select distinct fdpbatchkey as batchkey from fdp.f_psicle_fdp_amounttype where "
        "psiclebatchkey in ('" + os.getenv('batchkeys') + "')",
        "_s02.yaml", total_scenarios,
        total_idlist, claims_yaml_files)

    # generate test from LIC Reversal Accounting Event mapping yaml
    total_scenarios, total_idlist = generate_tests(
        "select distinct metadatabatchidentifier as batchkey from fdp.d_accountingevents_metadata where "
        "convert(varchar,metadatabatchidentifier) in ('" + os.getenv('batchkeys') + "')",
        "_reversalsinglequery.yaml", total_scenarios,
        total_idlist, claims_yaml_files)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_claims_singlequery(scenario, extra, request):
    claims_failed_records_count, claims_records_count = singlequery_test(scenario, extra, request)
    if claims_failed_records_count > 0 or claims_records_count == 0:
        if claims_records_count == 0:
            extra.append(extras.html("Empty record. Please make sure that the data is populated"))
        assert False
    else:
        assert True
