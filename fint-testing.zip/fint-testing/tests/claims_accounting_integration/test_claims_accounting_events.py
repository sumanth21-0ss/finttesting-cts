import collections
import utils.AccountingEventsSummary
import os
from database_comparator.ConnectionUtil import connect_database


batchkeys = os.getenv('batchkeys')


def pytest_generate_tests(metafunc):
    """
    Generate pytest scenarios
    :param metafunc:  metafunc
    """
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    connection = connect_database(os.getenv("database"))
    batchkeys_list = batchkeys.split(',')
    for batchkey in batchkeys_list:
        scenario = {}
        scenario['batchkey'] = str(batchkey)
        scenario['connection'] = connection
        total_scenarios['Scenarios'].append(scenario)
        total_idlist.append('batchkey - ' + str(batchkey))
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_premium(scenario, extra, request):
    reportfolder = request.config.getoption('reportfolder')
    utils.AccountingEventsSummary.accounting_event_summary(scenario, reportfolder)
