import collections
import os
from pytest_html import extras

from tests.FintAsserts import mapping_test, generate_tests


# Generate tests from yaml files
def pytest_generate_tests(metafunc):
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    claim_yaml_files = 'tests/claims_aurora_redshift_integration/claims_sttm_validation'
    # generate test from claim mapping yamls
    total_scenarios, total_idlist = generate_tests("select distinct sourcebatchkey as batchkey from "
                                                   "fdp.D_Claim where "
                                                   "sourcebatchkey in ("+os.getenv('batchkeys')+")",
                                                   "_Claim_mapping.yaml", total_scenarios, total_idlist,
                                                   claim_yaml_files)
    total_scenarios, total_idlist = generate_tests("select distinct sourcebatchkey as batchkey from "
                                                   "FDP.D_ClaimPeril where "
                                                   "sourcebatchkey in ("+os.getenv('batchkeys')+")",
                                                   "_ClaimPeril_mapping.yaml", total_scenarios, total_idlist,
                                                   claim_yaml_files)
    total_scenarios, total_idlist = generate_tests("select distinct sourcebatchkey as batchkey from "
                                                   "fdp.f_ClaimPayment where "
                                                   "sourcebatchkey in ("+os.getenv('batchkeys')+")",
                                                   "_ClaimPayment_mapping.yaml", total_scenarios, total_idlist,
                                                   claim_yaml_files)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)



def test_claims_mapping(scenario, extra, request):
    claims_matched_records_count, claims_mismatch_records_count, claims_missing_records_count = mapping_test(scenario,
                                                                                                             extra,
                                                                                                             request)
    if claims_missing_records_count == 0 and claims_matched_records_count == 0 and claims_mismatch_records_count == 0:
        extra.append(extras.html("Empty record. Please make sure that the data is populated"))
        assert False
    if claims_missing_records_count > 0 or claims_matched_records_count < 1 or claims_mismatch_records_count > 0:
        assert False
    else:
        assert True

