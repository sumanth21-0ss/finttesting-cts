import collections
import os

from pytest_html import extras
from tests.FintAsserts import mapping_test, generate_tests


# Generate tests from yaml files
def pytest_generate_tests(metafunc):
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    claims_yaml_files = 'tests/claims_dap_fdp_integration/claims_sttm_validation'
    # generate test from claim mapping yaml
    total_scenarios, total_idlist = generate_tests("select distinct batchkey from fdp.ln_claim where "
                                                   "batchkey in ("+os.getenv('batchkeys')+")",
                                                   "_claim_mapping.yaml", total_scenarios, total_idlist,
                                                   claims_yaml_files)
    # generate test from claimperil mapping
    total_scenarios, total_idlist = generate_tests("select distinct batchkey from fdp.ln_claimperil where "
                                                   "batchkey in ("+os.getenv('batchkeys')+")",
                                                   "_claimperil_mapping.yaml", total_scenarios, total_idlist,
                                                   claims_yaml_files)
    # generate test from claimpayment mapping
    total_scenarios, total_idlist = generate_tests("select distinct batchkey from fdp.ln_claimpayment where "
                                                   "batchkey in ("+os.getenv('batchkeys')+")",
                                                   "_claimpayment_mapping.yaml", total_scenarios, total_idlist,
                                                   claims_yaml_files)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_claims_mapping(scenario, extra, request):
    claims_matched_records_count, claims_mismatch_records_count, claims_missing_records_count = mapping_test(scenario,
                                                                                                             extra,
                                                                                                             request)
    if claims_missing_records_count == 0 and claims_matched_records_count == 0 and claims_mismatch_records_count == 0:
        extra.append(extras.html("Empty record. Please make sure that the data is populated"))
        assert False
    if claims_missing_records_count > 0 or claims_matched_records_count < 1 or claims_mismatch_records_count > 0:
        assert False
    else:
        assert True
