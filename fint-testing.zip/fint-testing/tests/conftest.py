import json
import os
import pytest
from lockfile import FileLock
from pandas import datetime
from py.xml import html
import re


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    fn = os.path.expanduser('~')+'/report.json'
    with FileLock(str(fn) + '.lock'):
        if os.path.exists(fn):
            with open(fn, 'r') as f:
                report = json.load(f)
        else:
            report_dir = 'reports/' + datetime.now().strftime("%d-%m-%Y-%H-%M-%S")
            report = {'report_dir': report_dir}
            with open(fn, 'w', encoding='utf-8') as f:
                json.dump(report, f)
    if not os.path.exists(report['report_dir']):
        os.makedirs(report['report_dir'])
    config.option.htmlpath = report['report_dir'] + "/Report.html"
    config.option.reportfolder = report['report_dir']


@pytest.mark.optionalhook
def pytest_metadata(metadata):
    metadata.pop("JAVA_HOME", None)
    metadata.pop("Packages", None)
    metadata.pop("Plugins", None)
    metadata.pop("Platform", None)
    metadata["env"] = os.getenv("env")
    metadata["database"] = os.getenv("database")
    metadata["batchkeys"] = os.getenv("batchkeys")


def pytest_html_results_summary(prefix, summary, postfix):
    fn = os.path.expanduser('~')+'/report.json'
    if os.path.exists(fn):
        os.remove(fn)
    total_tests = int(re.search('<p>(.+?) tests', str(summary[0])).group(1))
    tests_failed = int(re.search('failed">(.+?) failed', str(summary[9])).group(1))
    tests_passed = int(re.search('passed">(.+?) passed', str(summary[3])).group(1))
    try:
        pass_percentage = (tests_passed / total_tests) * 100
        fail_percentage = (tests_failed / total_tests) * 100
    except ZeroDivisionError:
        pass_percentage = 0
        fail_percentage = 0
    doc = html.html(html.p(""),
                    html.figure(html.br(), html.h3("Total: " + str(total_tests)),
                                style='background: radial-gradient(circle closest-side,white 0,white 17.22%,'
                                      'transparent 17.22%,transparent 82%,white 0),conic-gradient(from 117deg, '
                                      '#008000 0, #008000 ' + str(pass_percentage) + '%, #ff0000 ' + str(
                                      pass_percentage) + '%, #ff0000 ' + str(pass_percentage + fail_percentage) + '%, '
                                      '#ffa500 ' + str(pass_percentage + fail_percentage) + '%, #ffa500 100%);'
                                      'position: relative;width: 400px;min-height: 250px;margin: 0;'
                                      'outline: 0px solid #ccc;'))
    postfix.extend(doc)
