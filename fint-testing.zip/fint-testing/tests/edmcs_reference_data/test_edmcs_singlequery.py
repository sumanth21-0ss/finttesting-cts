import collections
import os

from pytest_html import extras
from tests.FintAsserts import singlequery_test, generate_tests


def pytest_generate_tests(metafunc):
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    claims_yaml_files = 'tests/edmcs_reference_data/edmcs_reference_data_validation'
    # generate test from LICAccounting Events mapping yaml
    total_scenarios, total_idlist = generate_tests(
        "select distinct batchkey as batchkey from fdp.LN_EDMCS_RefData where "
        "batchkey in ('" + os.getenv('batchkeys') + "')",
        "_aurora.yaml", total_scenarios,
        total_idlist, claims_yaml_files)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_edmcs_singlequery(scenario, extra, request):
    claims_failed_records_count, claims_records_count = singlequery_test(scenario, extra, request)
    if claims_failed_records_count > 0 or claims_records_count == 0:
        if claims_records_count == 0:
            extra.append(extras.html("Empty record. Please make sure that the data is populated"))
        assert False
    else:
        assert True
