import collections
import os

from pytest_html import extras
from tests.FintAsserts import mapping_test, generate_tests


def pytest_generate_tests(metafunc):
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    ins_yaml_files = 'tests/insurance_aurora_redshift_integration/insurance_sttm_validation'
    # generate test from contract mapping yaml
    total_scenarios, total_idlist = generate_tests("select distinct sourcebatchkey as batchkey from "
                                                   "fdp.d_InsuranceContractPolicy where "
                                                   "sourcebatchkey in ("+os.getenv('batchkeys')+")",
                                                   "_contract_mapping.yaml", total_scenarios,
                                                   total_idlist, ins_yaml_files)
    # generate test from product mapping
    total_scenarios, total_idlist = generate_tests("select distinct sourcebatchkey as batchkey from "
                                                   "fdp.d_insuranceproduct where "
                                                   "sourcebatchkey in ("+os.getenv('batchkeys')+")",
                                                   "_product_mapping.yaml", total_scenarios,
                                                   total_idlist, ins_yaml_files)
    # # generate test from object mapping
    total_scenarios, total_idlist = generate_tests("select distinct sourcebatchkey as batchkey from "
                                                    "fdp.d_insuredobject where "
                                                    "sourcebatchkey in ("+os.getenv('batchkeys')+")",
                                                    "_object_mapping.yaml", total_scenarios,
                                                    total_idlist, ins_yaml_files)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_insurance_integration_mapping(scenario, extra, request):
    ins_matched_records_count, ins_mismatch_records_count, ins_missing_records_count = mapping_test(scenario, extra,
                                                                                                    request)
    if ins_missing_records_count == 0 and ins_matched_records_count == 0 and ins_mismatch_records_count == 0:
        extra.append(extras.html("Empty record. Please make sure that the data is populated"))
        assert False
    if ins_missing_records_count > 0 or ins_matched_records_count < 1 or ins_mismatch_records_count > 0:
        assert False
    else:
        assert True