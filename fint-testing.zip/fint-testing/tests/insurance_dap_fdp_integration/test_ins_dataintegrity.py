import os

from pytest_html import extras
from database_comparator.DataBaseUtil import execute_query
import pandas as pd
from tests.FintAsserts import add_caption, color_fail_red


def test_insurance_integration_product_integrity(extra):
    product_orphan_records_query = "select * from fdp.ln_insuranceproductdetails p where not exists " \
                                   "(select insurancecontractidentifier, systemidentifier, lastmodifieddate " \
                                   "from fdp.ln_insurancecontractpolicydetails c where p.insurancecontractidentifier = " \
                                   "c.insurancecontractidentifier and p.systemidentifier = c.systemidentifier and " \
                                   "p.lastmodifieddate = c.lastmodifieddate)"
    product_orphan_records = execute_query(os.getenv("database"), product_orphan_records_query)
    product_orphan_records_df = pd.DataFrame(product_orphan_records)
    if len(product_orphan_records_df) > 0:
        extra.append(extras.html(
            product_orphan_records_df.style.set_caption('Product Orphan Records').set_table_styles(
                add_caption()).applymap(
                color_fail_red).render()))
        assert False


def test_insurance_integration_object_integrity(extra):
    object_orphan_records_query = "select * from fdp.ln_insuredobject o where not exists (select " \
                                  "productidentifier, insurancecontractidentifier, systemidentifier, " \
                                  "lastmodifieddate from fdp.ln_insuranceproductdetails p where   p.productidentifier = " \
                                  "o.productidentifier and p.insurancecontractidentifier = " \
                                  "o.insurancecontractidentifier and p.systemidentifier = o.systemidentifier and " \
                                  "p.lastmodifieddate = o.lastmodifieddate) "
    object_orphan_records = execute_query(os.getenv("database"), object_orphan_records_query)
    object_orphan_records_df = pd.DataFrame(object_orphan_records)
    if len(object_orphan_records_df) > 0:
        extra.append(extras.html(
            object_orphan_records_df.style.set_caption('Object Orphan Records').set_table_styles(
                add_caption()).applymap(
                color_fail_red).render()))
        assert False


def test_insurance_integration_coverage_integrity(extra):
    coverage_orphan_records_query = "select * from fdp.ln_insurancecoverage c where not exists (select " \
                                  "insuredobjectidentifier, productidentifier, insurancecontractidentifier, " \
                                  "systemidentifier, lastmodifieddate from fdp.ln_insuredobject o where   " \
                                  "c.insuredobjectidentifier = o.insuredobjectidentifier and c.productidentifier = " \
                                  "o.productidentifier and c.insurancecontractidentifier = " \
                                  "o.insurancecontractidentifier and c.systemidentifier = o.systemidentifier and " \
                                  "c.lastmodifieddate = o.lastmodifieddate) "
    coverage_orphan_records = execute_query(os.getenv("database"), coverage_orphan_records_query)
    coverage_orphan_records_df = pd.DataFrame(coverage_orphan_records)
    if len(coverage_orphan_records_df) > 0:
        extra.append(extras.html(
            coverage_orphan_records_df.style.set_caption('Coverage Orphan Records').set_table_styles(
                add_caption()).applymap(
                color_fail_red).render()))
        assert False
