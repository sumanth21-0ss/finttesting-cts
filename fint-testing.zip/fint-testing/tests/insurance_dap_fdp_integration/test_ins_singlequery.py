import collections
import os

from pytest_html import extras
from tests.FintAsserts import singlequery_test, generate_tests


def pytest_generate_tests(metafunc):
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    ins_yaml_files = 'tests/insurance_dap_fdp_integration/insurance_sttm_validation'
    # generate test from contract mapping yaml
    total_scenarios, total_idlist = generate_tests("select distinct batchkey from "
                                                   "fdp.ln_insurancecontractpolicydetails where "
                                                   "batchkey in ("+os.getenv('batchkeys')+")",
                                                   "_contract_singlequery.yaml", total_scenarios,
                                                   total_idlist, ins_yaml_files)
    # generate test from product mapping
    total_scenarios, total_idlist = generate_tests("select distinct batchkey from "
                                                   "fdp.ln_insuranceproductdetails where "
                                                   "batchkey in ("+os.getenv('batchkeys')+")",
                                                   "_products_singlequery.yaml", total_scenarios,
                                                   total_idlist, ins_yaml_files)
    # generate test from object mapping
    total_scenarios, total_idlist = generate_tests("select distinct batchkey from "
                                                   "fdp.ln_insuredobject where "
                                                   "batchkey in ("+os.getenv('batchkeys')+")",
                                                   "_insuredobjects_singlequery.yaml", total_scenarios,
                                                   total_idlist, ins_yaml_files)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_insurance_integration_singlequery(scenario, extra, request):
    ins_failed_records_count, ins_records_count = singlequery_test(scenario, extra, request)
    if ins_failed_records_count > 0 or ins_records_count == 0:
        if ins_records_count == 0:
            extra.append(extras.html("Empty record. Please make sure that the data is populated"))
        assert False
    else:
        assert True