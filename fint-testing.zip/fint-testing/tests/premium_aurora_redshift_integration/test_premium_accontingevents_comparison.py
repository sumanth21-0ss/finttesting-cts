import collections
import utils.PremiumAccountingEventsComparison
import pandas as pd
import os
from database_comparator.ConnectionUtil import connect_database


metadatabatchidentifier = os.getenv('batchkeys')


def header_query(metadatabatchidentifier):
    return "select 'DLG_UEP' as transactiontype,transactiondate ,transactionidentifier, metadatabatchidentifier,a.legalentityidentifier," \
          "b.ledgername ,c.postingflag,a.ahcseventcode,systemidentifier,underwriteridentifier,'' as subtype, '' as reason " \
          "from fdp.d_accountingevents_txnheader a " \
          "join fdp.d_legalentity b " \
          "on a.legalentityidentifier = b.legalentityidentifier " \
          "join fdp.d_ahcseventcode c " \
          "on a.ahcseventcode = c.ahcseventcode " \
          "where metadatabatchidentifier = '"+metadatabatchidentifier+"' order by transactionidentifier; "


def line_query(metadatabatchidentifier):
    return "select transactionidentifier,functionalamount,transactionalcurrencycode,Transactionalamount," \
            "brandidentifier,b.level3parentidentifier as channelidentifier,Productidentifier,'000' as SourceICO,'' as FinancialElement" \
            " from fdp.f_accountingevents_txnline a " \
            "join "\
            "fdp.d_channel b on a.channelidentifier = b.channelidentifier " \
            "where metadatabatchidentifier = '"+metadatabatchidentifier+"' and transactionalamount <> '0.000000' " \
            "order by transactionidentifier,productidentifier,channelidentifier;"


def pytest_generate_tests(metafunc):
    """
    Generate pytest scenarios
    :param metafunc:  metafunc
    """
    total_scenarios = collections.defaultdict(list)
    total_idlist = []
    connection = connect_database(os.getenv("database"))
    scenario = {}
    scenario['header'] = pd.read_sql_query(header_query(metadatabatchidentifier), connection)
    scenario['line'] = pd.read_sql_query(line_query(metadatabatchidentifier), connection)
    scenario['metadatabatchidentifier'] = str(metadatabatchidentifier)
    scenario['filepath'] = 'C:\\AccountingEvents\\'
    total_scenarios['Scenarios'].append(scenario)
    total_idlist.append(metadatabatchidentifier)
    metafunc.parametrize('scenario', total_scenarios["Scenarios"], ids=total_idlist)


def test_accounting_events_comparison(scenario,extra, request):
    reportfolder = request.config.getoption('reportfolder')
    utils.PremiumAccountingEventsComparison.compare_file_and_data(scenario, reportfolder)
