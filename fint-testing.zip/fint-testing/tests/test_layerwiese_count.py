import utils.AllIntegartionsLayerWiseCount


def test_layer_count():
    utils.AllIntegartionsLayerWiseCount.layerwisecount()
