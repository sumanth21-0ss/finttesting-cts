import pandas as pd
from pandas import ExcelWriter


def color_fail_red(val):
    """
    apply style to a dataframe, to differentiate failed data
    :param val: vaue in a cell, that has to be marked pass/fail
    :return: style object
    """
    if val == 'False':
        color = 'orange'
    elif val == 'True':
        color = 'green'
    else:
        color = 'white'
    return 'background-color: %s' % color


def amount_types_coverage(batchkey, connection):
    total_amount_types = {
        'amounttypeidentifier': ['CLM_IBNR_AMT', 'PS_RES', 'PS_ENID', 'CLM_ENID', 'CHE_RES', 'CHE_ENID', 'EFFC_CHNG_YC',
                                 'RA', 'DISC_RA', 'OS_CLM', 'RIBD_RES', 'DISC_RIBD_RES',
                                 'UNDISC_PWM', 'DISC_PWM', 'UNWIN_DISC', 'RA_EOC', 'RA_UOD', 'RIBD_RES_EOC',
                                 'RIBD_RES_UOD']}
    total_amount_types_df = pd.DataFrame.from_dict(total_amount_types)
    amount_types_received_query = "select amounttypeidentifier, sum(amounttypevalue) from fdp.f_psicleoutputamount  " \
                                  "where psiclebatchkey = '" + batchkey + "' and amounttypeidentifier in ( " \
                                                                          "'CLM_IBNR_AMT','PS_RES','PS_ENID', " \
                                                                          "'CLM_ENID','CHE_RES','CHE_ENID', " \
                                                                          "'EFFC_CHNG_YC','RA','DISC_RA', " \
                                                                          "'OS_CLM','RIBD_RES', " \
                                                                          "'DISC_RIBD_RES','UNDISC_PWM', " \
                                                                          "'DISC_PWM','UNWIN_DISC','RA_EOC', " \
                                                                          "'RA_UOD','RIBD_RES_EOC', " \
                                                                          "'RIBD_RES_UOD')group by  " \
                                                                          "amounttypeidentifier; "
    amount_types_received_df = pd.read_sql_query(amount_types_received_query, connection)
    amount_type_coverage = (len(amount_types_received_df) / len(total_amount_types_df)) * 100
    total_amount_types_df['coverage'] = total_amount_types_df['amounttypeidentifier'].isin(
        amount_types_received_df['amounttypeidentifier'])
    total_amount_types_df = total_amount_types_df.astype(str)
    return total_amount_types_df, amount_type_coverage


def transaction_event_coverage(fdp_batch_key, connection):
    total_transaction_events_query = "select distinct dtraneventsid  from fdp.d_accountingevents_txnheader where transactionidentifier in" \
                                    "(select transactionidentifier from fdp.f_accountingevents_txnline_lic where metadatabatchidentifier = '"+fdp_batch_key+"' and functionalamount != '0.000000')"
    entity_identifiers_received_query = "select distinct UnderwriterIdentifier from  " \
                                        "fdp.d_accountingevents_txnheader where metadatabatchidentifier='"+fdp_batch_key+"'"
    total_transaction_events_df = pd.read_sql_query(total_transaction_events_query, connection)
    entity_identifiers_received_df = pd.read_sql_query(entity_identifiers_received_query, connection)
    transaction_events_received_query = "select distinct  dtraneventsid from  " \
                                        "fdp.d_accountingevents_txnheader where metadatabatchidentifier='"+fdp_batch_key+"'"
    transaction_events_received_df = pd.read_sql_query(transaction_events_received_query, connection)
    transaction_events_received_coverage = (len(transaction_events_received_df) / (len(
        total_transaction_events_df) * len(entity_identifiers_received_df))) * 100
    transaction_events_received_df['coverage'] = transaction_events_received_df['dtraneventsid'].isin(
        total_transaction_events_df['dtraneventsid'])
    transaction_events_received_df = transaction_events_received_df.astype(str)
    return transaction_events_received_df, transaction_events_received_coverage


def amount_type_uncovered_records(batchkey, connection):
    amount_type_uncovered_query = "select * from fdp.f_psicleoutputamount  " \
                                  "where psiclebatchkey = '" + batchkey + "' and amounttypeidentifier not in ( " \
                                                                          "'CLM_IBNR_AMT','PS_RES','PS_ENID','CLM_ENID','CHE_RES','CHE_ENID', " \
                                                                          "'EFFC_CHNG_YC','RA','DISC_RA','OS_CLM','RIBD_RES','DISC_RIBD_RES','UNDISC_PWM', " \
                                                                          "'DISC_PWM','UNWIN_DISC','RA_EOC','RA_UOD','RIBD_RES_EOC','RIBD_RES_UOD') LIMIT 1000; "
    amount_type_uncovered_df = pd.read_sql_query(amount_type_uncovered_query, connection)
    return amount_type_uncovered_df


def transaction_line_data(batchkey, fdp_batch_key, connection):

    with_class_query = "WITH RESERVEFLAG AS( " \
						"SELECT D.fdpbatchkey,D.psiclebatchkey,D.Dtraneventsid,cast(D.transactionidentifier as varchar) " \
						",D.underwriteridentifier,D.reservingflag,D.brandidentifier,D.productidentifier,D.reportingperiodidentifier,D.duwritercompanyid,D.reinsurancetypeidentifier " \
						",D.reinsurancebasisidentifier,D.currencycodeidentifier,D.clmibnramt,D.psres,D.clmenid,D.cheenid,D.psenid,D.discclmenid,D.disccheenid,D.discpsenid,D.discclmres,D.disccheres,D.discpsres,D.clmeniduod,D.clmenideoc,D.cheeniduod,D.cheenideoc " \
						",D.cheresuod,D.chereseoc,D.psresuod,D.psreseoc,D.ra,D.discra,D.abeclres,D.chepaidamt,D.clmincamt,D.clmnum,D.clmreseoc,D.clmresuod,D.discpwm,D.diversben,D.effcchngyc,D.clmibnrnb,D.othrparm,D.osclm,D.clmpaidamt,D.ppupstdben,D.ppupredben,D.pspaidamt " \
						",D.psultamt,D.ribdres,D.ttlparm,D.clmultamt,D.clmultnm,D.undiscpwm,D.unwindisc,D.psenideoc,D.pseniduod,D.cheres,D.discribdres,D.discraenid,D.discribdenid,D.eprem,D.exp,D.raenid,D.raenideoc,D.raeniduod,D.raeoc,D.rauod,D.ribdenid,D.ribdenideoc " \
						",D.ribdeniduod,D.ribdreseoc,D.ribdresuod, " \
						"CASE " \
						"WHEN D.DTRANEVENTSID IN ('TE001','TE007','TE015','TE018','TE024','TE027') THEN (D.ClmIbnrAmt+D.PsRes+D.PsEnid+D.ClmEnid) " \
						"WHEN D.DTRANEVENTSID IN ('TE002','TE008') THEN (D.CheRes+D.CheEnid) " \
						"WHEN D.DTRANEVENTSID IN ('TE003','TE009') THEN (D.UndiscPwm-D.DiscPwm) " \
						"WHEN D.DTRANEVENTSID IN ('TE004','TE010') THEN (-D.UnwinDisc-D.EffcChngYc+D.RaUod+D.RaEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE005','TE011','TE019','TE028') THEN (D.Ra) " \
						"WHEN D.DTRANEVENTSID IN ('TE006','TE012','TE020','TE029') THEN (D.DiscRa-D.Ra) " \
						"WHEN D.DTRANEVENTSID IN ('TE014','TE017','TE023','TE026') THEN (d.OsClm) " \
						"WHEN D.DTRANEVENTSID IN ('TE016') THEN (D.RibdRes) " \
						"WHEN D.DTRANEVENTSID IN ('TE021','TE030') THEN (D.UndiscPwm-D.DiscPwm-D.discribdres+D.RibdRes) " \
						"WHEN D.DTRANEVENTSID IN ('TE022','TE031') THEN (-D.UnwinDisc-D.EffcChngYc+D.RaUod+D.RaEoc+D.RibdResUod+D.RibdResEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE025') THEN (D.discribdres-D.RibdRes) " \
						"ELSE '0' END AS te_transactionalamount, " \
						"CASE " \
						"WHEN D.DTRANEVENTSID IN ('TE001','TE007') THEN (D.ClmIbnrAmt+D.PsRes+D.PsEnid+D.ClmEnid) " \
						"WHEN D.DTRANEVENTSID IN ('TE002','TE008') THEN (D.CheRes+D.CheEnid) " \
						"WHEN D.DTRANEVENTSID IN ('TE003','TE009') THEN (D.UndiscPwm-D.DiscPwm) " \
						"WHEN D.DTRANEVENTSID IN ('TE004','TE010') THEN (-D.UnwinDisc-D.EffcChngYc+D.RaUod+D.RaEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE005','TE011','TE019','TE028') THEN (D.Ra) " \
						"WHEN D.DTRANEVENTSID IN ('TE006','TE012','TE020','TE029') THEN (D.DiscRa-D.Ra) " \
						"WHEN (D.DTRANEVENTSID IN ('TE014','TE023') AND D.ReinsuranceTypeIdentifier in ('OMQS','FloodRe','QSXoL')) THEN (d.OsClm) " \
						"WHEN (D.DTRANEVENTSID IN ('TE015','TE024') AND D.ReinsuranceTypeIdentifier in ('OMQS','FloodRe','QSXoL')) THEN (D.ClmIbnrAmt+D.PsRes+D.PsEnid+D.ClmEnid) " \
						"WHEN D.DTRANEVENTSID IN ('TE016') THEN (D.RibdRes) " \
						"WHEN (D.DTRANEVENTSID IN ('TE017','TE026') AND D.ReinsuranceTypeIdentifier = 'OM XoL') THEN (d.OsClm) " \
						"WHEN (D.DTRANEVENTSID IN ('TE018','TE027') AND D.ReinsuranceTypeIdentifier = 'OM XoL') THEN (D.ClmIbnrAmt+D.PsRes+D.PsEnid+D.ClmEnid) " \
						"WHEN D.DTRANEVENTSID IN ('TE021','TE030') THEN (D.UndiscPwm-D.DiscPwm-D.discribdres+D.RibdRes) " \
						"WHEN D.DTRANEVENTSID IN ('TE022','TE031') THEN (-D.UnwinDisc-D.EffcChngYc+D.RaUod+D.RaEoc+D.RibdResUod+D.RibdResEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE025') THEN (D.discribdres-D.RibdRes) " \
						"ELSE '0' END AS te_rib_transactionalamount " \
						"FROM " \
						"(select C.*,B.dtraneventsid,B.TransactionIdentifier from " \
						"(SELECT " \
						"A.UnderwriterIdentifier,A.ReservingFlag,A.BrandIdentifier,A.ProductIdentifier,A.ReportingPeriodIdentifier,A.DUwriterCompanyID,A.ReinsuranceTypeIdentifier " \
						",A.ReinsuranceBasisIdentifier,A.Fdpbatchkey,A.PsicleBatchKey,A.CurrencyCodeIdentifier,ISNULL(SUM(A.ClmIBNRAmt),0) AS ClmIBNRAmt,ISNULL(SUM(A.PsRes),0) AS PsRes,ISNULL(SUM(A.ClmENID),0) AS ClmENID,ISNULL(SUM(A.CheENID),0) AS CheENID,ISNULL(SUM(A.PsENID),0) AS PsENID,ISNULL(SUM(A.DiscClmENID),0) AS DiscClmENID,ISNULL(SUM(A.DiscCheENID),0) AS DiscCheENID,ISNULL(SUM(A.DiscPsENID),0) AS DiscPsENID,ISNULL(SUM(A.DiscClmRes),0) AS DiscClmRes,ISNULL(SUM(A.DiscCheRes),0) AS DiscCheRes,ISNULL(SUM(A.DiscPsRes),0) AS DiscPsRes,ISNULL(SUM(A.ClmENIDUod),0) AS ClmENIDUod,ISNULL(SUM(A.ClmENIDEoc),0) AS ClmENIDEoc,ISNULL(SUM(A.CheENIDUod),0) AS CheENIDUod,ISNULL(SUM(A.CheENIDEoc),0) AS CheENIDEoc,ISNULL(SUM(A.CheResUod),0) AS CheResUod,ISNULL(SUM(A.CheResEoc),0) AS CheResEoc,ISNULL(SUM(A.PsResUod),0) AS PsResUod,ISNULL(SUM(A.PsResEoc),0) AS PsResEoc,ISNULL(SUM(A.Ra),0) AS Ra,ISNULL(SUM(A.DiscRa),0) AS DiscRa,ISNULL(SUM(A.AbeClRes),0) AS AbeClRes,ISNULL(SUM(A.ChePaidAmt),0) AS ChePaidAmt " \
						",ISNULL(SUM(A.ClmIncAmt),0) AS ClmIncAmt,ISNULL(SUM(A.ClmNum),0) AS ClmNum,ISNULL(SUM(A.ClmResEoc),0) AS ClmResEoc,ISNULL(SUM(A.ClmResUod),0) AS ClmResUod,ISNULL(SUM(A.DiscPwm),0) AS DiscPwm,ISNULL(SUM(A.DiversBen),0) AS DiversBen,ISNULL(SUM(A.EffcChngYc),0) AS EffcChngYc,ISNULL(SUM(A.ClmIBNRNb),0) AS ClmIBNRNb,ISNULL(SUM(A.OthrParm),0) AS OthrParm,ISNULL(SUM(A.OsClm),0) AS OsClm,ISNULL(SUM(A.ClmPaidAmt),0) AS ClmPaidAmt,ISNULL(SUM(A.PpuPstdBen),0) AS PpuPstdBen,ISNULL(SUM(A.PpuPredBen),0) AS PpuPredBen,ISNULL(SUM(A.PsPaidAmt),0) AS PsPaidAmt,ISNULL(SUM(A.PsUltAmt),0) AS PsUltAmt,ISNULL(SUM(A.RibdRes),0) AS RibdRes,ISNULL(SUM(A.TtlParm),0) AS TtlParm,ISNULL(SUM(A.ClmUltAmt),0) AS ClmUltAmt,ISNULL(SUM(A.ClmUltNm),0) AS ClmUltNm,ISNULL(SUM(A.UndiscPwm),0) AS UndiscPwm,ISNULL(SUM(A.UnwinDisc),0) AS UnwinDisc,ISNULL(SUM(A.PsENIDEoc),0) AS PsENIDEoc,ISNULL(SUM(A.PsENIDUod),0) AS PsENIDUod,ISNULL(SUM(A.CheRes),0) AS CheRes,ISNULL(SUM(A.DiscRibdRes),0) AS DiscRibdRes,ISNULL(SUM(A.DiscRaENID),0) AS DiscRaENID " \
						",ISNULL(SUM(A.DiscRibdENID),0) AS DiscRibdENID,ISNULL(SUM(A.Eprem),0) AS Eprem,ISNULL(SUM(A.Exp),0) AS Exp,ISNULL(SUM(A.RaENID),0) AS RaENID,ISNULL(SUM(A.RaENIDEoc),0) AS RaENIDEoc,ISNULL(SUM(A.RaENIDUod),0) AS RaENIDUod,ISNULL(SUM(A.RaEoc),0) AS RaEoc,ISNULL(SUM(A.RaUod),0) AS RaUod,ISNULL(SUM(A.RibdENID),0) AS RibdENID,ISNULL(SUM(A.RibdENIDEoc),0) AS RibdENIDEoc,ISNULL(SUM(A.RibdENIDUod),0) AS RibdENIDUod,ISNULL(SUM(A.RibdResEoc),0) AS RibdResEoc,ISNULL(SUM(A.RibdResUod),0) AS RibdResUod " \
						"FROM " \
						"fdp.F_Psicle_FDP_AmountType A " \
						"WHERE A.PsicleBatchKey = '" + batchkey + "' " \
						"GROUP BY " \
						"A.UnderwriterIdentifier,A.ReservingFlag,A.BrandIdentifier,A.ProductIdentifier,A.ReportingPeriodIdentifier,A.DUwriterCompanyID,A.ReinsuranceTypeIdentifier,A.ReinsuranceBasisIdentifier,A.Fdpbatchkey,A.PsicleBatchKey,A.CurrencyCodeIdentifier) C left join " \
						"fdp.D_AccountingEvents_TxnHeader B " \
						"ON " \
						"B.UnderwriterIdentifier = C.UnderwriterIdentifier " \
						"AND B.ReservingFlag = C.ReservingFlag " \
						"AND B.MetadataBatchIdentifier = C.Fdpbatchkey) D inner join " \
						"(select x.dtraneventsid,x.calculationlogic,x.reinsurancebasisidentifier,x.reinsurancetypeidentifier,y.reservesflag " \
						"from fdp.d_fdp_gl_calc x inner join " \
						"fdp.D_TransactionEvents_Mapping y " \
						"on x.dtraneventsid = y.dtraneventsid) E " \
						"ON D.REINSURANCEBASISIDENTIFIER = E.REINSURANCEBASISIDENTIFIER " \
						"AND D.ReservingFlag = E.reservesflag " \
						"AND D.dtraneventsid = E.dtraneventsid), " \
						"ALLRESERVEFLAG AS( " \
						"SELECT D.fdpbatchkey,D.psiclebatchkey,D.Dtraneventsid,cast(D.transactionidentifier as varchar) " \
						",D.underwriteridentifier,D.reservingflag,D.brandidentifier,D.productidentifier,D.reportingperiodidentifier,D.duwritercompanyid,D.reinsurancetypeidentifier " \
						",D.reinsurancebasisidentifier,D.currencycodeidentifier,D.clmibnramt,D.psres,D.clmenid,D.cheenid,D.psenid,D.discclmenid,D.disccheenid,D.discpsenid,D.discclmres,D.disccheres,D.discpsres,D.clmeniduod,D.clmenideoc,D.cheeniduod,D.cheenideoc " \
						",D.cheresuod,D.chereseoc,D.psresuod,D.psreseoc,D.ra,D.discra,D.abeclres,D.chepaidamt,D.clmincamt,D.clmnum,D.clmreseoc,D.clmresuod,D.discpwm,D.diversben,D.effcchngyc,D.clmibnrnb,D.othrparm,D.osclm,D.clmpaidamt,D.ppupstdben,D.ppupredben,D.pspaidamt " \
						",D.psultamt,D.ribdres,D.ttlparm,D.clmultamt,D.clmultnm,D.undiscpwm,D.unwindisc,D.psenideoc,D.pseniduod,D.cheres,D.discribdres,D.discraenid,D.discribdenid,D.eprem,D.exp,D.raenid,D.raenideoc,D.raeniduod,D.raeoc,D.rauod,D.ribdenid,D.ribdenideoc " \
						",D.ribdeniduod,D.ribdreseoc,D.ribdresuod, " \
						"CASE " \
						"WHEN D.DTRANEVENTSID IN ('TE013') THEN (D.UnwinDisc+D.EffcChngYc-D.RaUod-D.RaEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE032') THEN (D.RibdRes) " \
						"WHEN D.DTRANEVENTSID IN ('TE033') THEN (D.RibdResUod+D.RibdResEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE034') THEN (D.UnwinDisc+D.EffcChngYc-D.RaUod-D.RaEoc-D.RibdResUod-D.RibdResEoc) " \
						"ELSE '0' END AS te_transactionalamount, " \
						"CASE " \
						"WHEN D.DTRANEVENTSID IN ('TE013') THEN (D.UnwinDisc+D.EffcChngYc-D.RaUod-D.RaEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE032') THEN (D.RibdRes) " \
						"WHEN D.DTRANEVENTSID IN ('TE033') THEN (D.RibdResUod+D.RibdResEoc) " \
						"WHEN D.DTRANEVENTSID IN ('TE034') THEN (D.UnwinDisc+D.EffcChngYc-D.RaUod-D.RaEoc-D.RibdResUod-D.RibdResEoc) " \
						"ELSE '0' END AS te_rib_transactionalamount " \
						"FROM " \
						"(select C.*,B.dtraneventsid,B.TransactionIdentifier from " \
						"(SELECT " \
						"A.UnderwriterIdentifier,A.ReservingFlag,A.BrandIdentifier,A.ProductIdentifier,A.ReportingPeriodIdentifier,A.DUwriterCompanyID,A.ReinsuranceTypeIdentifier " \
						",A.ReinsuranceBasisIdentifier,A.Fdpbatchkey,A.PsicleBatchKey,A.CurrencyCodeIdentifier,ISNULL(SUM(A.ClmIBNRAmt),0) AS ClmIBNRAmt,ISNULL(SUM(A.PsRes),0) AS PsRes,ISNULL(SUM(A.ClmENID),0) AS ClmENID,ISNULL(SUM(A.CheENID),0) AS CheENID,ISNULL(SUM(A.PsENID),0) AS PsENID,ISNULL(SUM(A.DiscClmENID),0) AS DiscClmENID,ISNULL(SUM(A.DiscCheENID),0) AS DiscCheENID,ISNULL(SUM(A.DiscPsENID),0) AS DiscPsENID,ISNULL(SUM(A.DiscClmRes),0) AS DiscClmRes,ISNULL(SUM(A.DiscCheRes),0) AS DiscCheRes,ISNULL(SUM(A.DiscPsRes),0) AS DiscPsRes,ISNULL(SUM(A.ClmENIDUod),0) AS ClmENIDUod,ISNULL(SUM(A.ClmENIDEoc),0) AS ClmENIDEoc,ISNULL(SUM(A.CheENIDUod),0) AS CheENIDUod,ISNULL(SUM(A.CheENIDEoc),0) AS CheENIDEoc,ISNULL(SUM(A.CheResUod),0) AS CheResUod,ISNULL(SUM(A.CheResEoc),0) AS CheResEoc,ISNULL(SUM(A.PsResUod),0) AS PsResUod,ISNULL(SUM(A.PsResEoc),0) AS PsResEoc,ISNULL(SUM(A.Ra),0) AS Ra,ISNULL(SUM(A.DiscRa),0) AS DiscRa,ISNULL(SUM(A.AbeClRes),0) AS AbeClRes,ISNULL(SUM(A.ChePaidAmt),0) AS ChePaidAmt " \
						",ISNULL(SUM(A.ClmIncAmt),0) AS ClmIncAmt,ISNULL(SUM(A.ClmNum),0) AS ClmNum,ISNULL(SUM(A.ClmResEoc),0) AS ClmResEoc,ISNULL(SUM(A.ClmResUod),0) AS ClmResUod,ISNULL(SUM(A.DiscPwm),0) AS DiscPwm,ISNULL(SUM(A.DiversBen),0) AS DiversBen,ISNULL(SUM(A.EffcChngYc),0) AS EffcChngYc,ISNULL(SUM(A.ClmIBNRNb),0) AS ClmIBNRNb,ISNULL(SUM(A.OthrParm),0) AS OthrParm,ISNULL(SUM(A.OsClm),0) AS OsClm,ISNULL(SUM(A.ClmPaidAmt),0) AS ClmPaidAmt,ISNULL(SUM(A.PpuPstdBen),0) AS PpuPstdBen,ISNULL(SUM(A.PpuPredBen),0) AS PpuPredBen,ISNULL(SUM(A.PsPaidAmt),0) AS PsPaidAmt,ISNULL(SUM(A.PsUltAmt),0) AS PsUltAmt,ISNULL(SUM(A.RibdRes),0) AS RibdRes,ISNULL(SUM(A.TtlParm),0) AS TtlParm,ISNULL(SUM(A.ClmUltAmt),0) AS ClmUltAmt,ISNULL(SUM(A.ClmUltNm),0) AS ClmUltNm,ISNULL(SUM(A.UndiscPwm),0) AS UndiscPwm,ISNULL(SUM(A.UnwinDisc),0) AS UnwinDisc,ISNULL(SUM(A.PsENIDEoc),0) AS PsENIDEoc,ISNULL(SUM(A.PsENIDUod),0) AS PsENIDUod,ISNULL(SUM(A.CheRes),0) AS CheRes,ISNULL(SUM(A.DiscRibdRes),0) AS DiscRibdRes,ISNULL(SUM(A.DiscRaENID),0) AS DiscRaENID " \
						",ISNULL(SUM(A.DiscRibdENID),0) AS DiscRibdENID,ISNULL(SUM(A.Eprem),0) AS Eprem,ISNULL(SUM(A.Exp),0) AS Exp,ISNULL(SUM(A.RaENID),0) AS RaENID,ISNULL(SUM(A.RaENIDEoc),0) AS RaENIDEoc,ISNULL(SUM(A.RaENIDUod),0) AS RaENIDUod,ISNULL(SUM(A.RaEoc),0) AS RaEoc,ISNULL(SUM(A.RaUod),0) AS RaUod,ISNULL(SUM(A.RibdENID),0) AS RibdENID,ISNULL(SUM(A.RibdENIDEoc),0) AS RibdENIDEoc,ISNULL(SUM(A.RibdENIDUod),0) AS RibdENIDUod,ISNULL(SUM(A.RibdResEoc),0) AS RibdResEoc,ISNULL(SUM(A.RibdResUod),0) AS RibdResUod " \
						"FROM " \
						"fdp.F_Psicle_FDP_AmountType A " \
						"WHERE A.PsicleBatchKey = '" + batchkey + "' " \
						"GROUP BY " \
						"A.UnderwriterIdentifier,A.ReservingFlag,A.BrandIdentifier,A.ProductIdentifier,A.ReportingPeriodIdentifier,A.DUwriterCompanyID,A.ReinsuranceTypeIdentifier,A.ReinsuranceBasisIdentifier,A.Fdpbatchkey,A.PsicleBatchKey,A.CurrencyCodeIdentifier) C left join " \
						"fdp.D_AccountingEvents_TxnHeader B " \
						"ON " \
						"B.UnderwriterIdentifier = C.UnderwriterIdentifier " \
						"AND B.MetadataBatchIdentifier = C.Fdpbatchkey " \
						"where b.dtraneventsid in ('TE013','TE032','TE033','TE034') ) D inner join " \
						"(select x.dtraneventsid,x.calculationlogic,x.reinsurancebasisidentifier,x.reinsurancetypeidentifier,y.reservesflag " \
						"from fdp.d_fdp_gl_calc x inner join " \
						"fdp.D_TransactionEvents_Mapping y " \
						"on x.dtraneventsid = y.dtraneventsid) E " \
						"ON D.REINSURANCEBASISIDENTIFIER = E.REINSURANCEBASISIDENTIFIER " \
						"AND D.dtraneventsid = E.dtraneventsid)"
    automation_select_query = "select  a.metadatabatchidentifier,c.transactionidentifier,c.CurrencyCodeIdentifier as  " \
                              "functionalcurrencycode,c.CurrencyCodeIdentifier as transactionalcurrencycode, " \
                              "c.BrandIdentifier as fshbrand,'00000' as fshchannel,c.ProductIdentifier as fshproduct, " \
                              "c.te_rib_transactionalamount AS functionalamount,c.te_rib_transactionalamount as  " \
                              "transactionalamount from fdp.D_AccountingEvents_TxnHeader a join(select dtraneventsid, " \
                              "transactionidentifier,underwriteridentifier,CurrencyCodeIdentifier,BrandIdentifier, " \
                              "ProductIdentifier,sum(te_rib_transactionalamount) as te_rib_transactionalamount FROM ( " \
                              "SELECT * FROM RESERVEFLAG UNION SELECT * FROM ALLRESERVEFLAG)GROUP BY dtraneventsid, " \
                              "transactionidentifier,underwriteridentifier,CurrencyCodeIdentifier,BrandIdentifier, " \
                              "ProductIdentifier) c on a.transactionidentifier = c.transactionidentifier WHERE  " \
                              "a.MetadataBatchIdentifier = '"+fdp_batch_key+"' "
    informatica_select_query = "SELECT metadatabatchidentifier,cast(transactionidentifier as varchar), " \
                               "functionalcurrencycode,transactionalcurrencycode,fshbrand,fshchannel,fshproduct, " \
                               "isnull(functionalamount,0) as fn_amount,isnull(transactionalamount,0) as tn_amount FROM fdp.F_AccountingEvents_TxnLine_LIC WHERE  " \
                               "MetadataBatchIdentifier = '"+fdp_batch_key+"' "
    expected_query_1 = with_class_query + automation_select_query + " except " + informatica_select_query
    expected_query_2 = with_class_query + informatica_select_query + " except " + automation_select_query
    expected_1_df = pd.read_sql_query(expected_query_1, connection)
    expected_2_df = pd.read_sql_query(expected_query_2, connection)
    return expected_1_df, expected_2_df


def accounting_event_summary(scenario, reportfolder):
    fdp_batch_key_query = "select batch_key from fdp.dlg_fdp_rs_ctl_batch where pattern_type = 'LICAccountingEvents'and source_batch_key_bigint = (select batch_key from fdp.dlg_fdp_rs_ctl_batch where status_code < '9000' and source_batch_key_varchar = '" + scenario['batchkey'] + "')"
    fdp_batch_key = pd.read_sql_query(fdp_batch_key_query, scenario['connection'])['batch_key'][0].astype(str)
    total_amount_types_df, amount_type_coverage = amount_types_coverage(scenario['batchkey'], scenario['connection'])
    total_transaction_events_df, transaction_events_received_coverage = transaction_event_coverage(fdp_batch_key,
                                                                                                   scenario[
                                                                                                       'connection'])
    expected_1_df, expected_2_df = transaction_line_data(scenario['batchkey'], fdp_batch_key, scenario['connection'])
    amount_type_uncovered_df = amount_type_uncovered_records(scenario['batchkey'], scenario['connection'])
    details_df = pd.DataFrame(columns=['key', 'value']).astype(str)
    details_df = details_df.append({'key': 'psicle batch key', 'value': scenario['batchkey']}, ignore_index=True)
    details_df = details_df.append({'key': 'amount type coverage', 'value': str(amount_type_coverage) + "%"},
                                   ignore_index=True)
    details_df = details_df.append(
        {'key': 'calculation coverage', 'value': str(transaction_events_received_coverage) + "%"}, ignore_index=True)
    details_df = details_df.append({'key': 'total differences', 'value': str(len(expected_1_df) + len(expected_2_df))},
                                   ignore_index=True)

    filename = reportfolder + "//Report_" + scenario['batchkey'] + ".xlsx"
    with ExcelWriter(filename, engine="xlsxwriter") as writer:
        details_df.to_excel(writer, index=False, sheet_name='summary')
        for column in details_df:
            column_width = max(details_df[column].astype(str).map(len).max(), len(column)) + 2
            col_idx = details_df.columns.get_loc(column)
            writer.sheets['summary'].set_column(col_idx, col_idx, column_width)
        total_transaction_events_df.style.applymap(color_fail_red).to_excel(writer, index=False,
                                                                            sheet_name='transaction_events')
        for column in total_transaction_events_df:
            column_width = max(total_transaction_events_df[column].astype(str).map(len).max(), len(column)) + 2
            col_idx = total_transaction_events_df.columns.get_loc(column)
            writer.sheets['transaction_events'].set_column(col_idx, col_idx, column_width)
        total_amount_types_df.style.applymap(color_fail_red).to_excel(writer, index=False,
                                                                      sheet_name='amount types covered')
        for column in total_amount_types_df:
            column_width = max(total_amount_types_df[column].astype(str).map(len).max(), len(column)) + 2
            col_idx = total_amount_types_df.columns.get_loc(column)
            writer.sheets['amount types covered'].set_column(col_idx, col_idx, column_width)
        amount_type_uncovered_df.to_excel(writer, index=False, sheet_name='records not covered')
        for column in amount_type_uncovered_df:
            column_width = max(amount_type_uncovered_df[column].astype(str).map(len).max(), len(column)) + 2
            col_idx = amount_type_uncovered_df.columns.get_loc(column)
            writer.sheets['records not covered'].set_column(col_idx, col_idx, column_width)
        automation_sheet_name = 'automation diff'
        expected_1_df.to_excel(writer, index=False, startrow=4, startcol=0, sheet_name=automation_sheet_name)
        writer.sheets[automation_sheet_name].write(1, 1,
                                                   'records that are in automation calculated table, but missing in '
                                                   'informatica tables')
        for column in expected_1_df:
            column_width = len(expected_1_df[column].name) + 2
            col_idx = expected_1_df.columns.get_loc(column)
            writer.sheets[automation_sheet_name].set_column(col_idx, col_idx, column_width)
        informatica_sheet_name = 'informatica diff'
        expected_2_df.to_excel(writer, index=False, startrow=4, startcol=0, sheet_name=informatica_sheet_name)
        writer.sheets[informatica_sheet_name].write(1, 1,
                                                    'records that are in informatica tables but missing in automation '
                                                    'calculated table')
        if len(expected_2_df) != 0:
            for column in expected_2_df:
                column_width = len(expected_2_df[column].name) + 2
                col_idx = expected_2_df.columns.get_loc(column)
                writer.sheets[informatica_sheet_name].set_column(col_idx, col_idx, column_width)
