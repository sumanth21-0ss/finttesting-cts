import pandas as pd
import psycopg2
import os


def layerwisecount():
    """
    Fetch the row count of all layer tables for insurance, claims and Premium
    """
    connection = psycopg2.connect(user=os.getenv("postgresusername"),
                                  password=os.getenv("postgrespassword"),
                                  host='ifrs-test-aurora-cluster.cluster-cnolo9owvhht.eu-west-1.rds.amazonaws.com',
                                  port='5432',
                                  database='dapload')

    insurance = {'insurancecontractpolicydetails': ['29778001', '3', '4'],
                 'insuranceproductdetails': ['29779001'],
                 'insuredobject': ['29780001'],
                 }

    claims = {'claim': ['29781001'],
              'claimperil': ['29785001'],
              'claimpayment': ['29786001', '7', '8'],
              }

    premium = {'GrossWrittenPremiumTransactions': ['29784001', '2', '3'],
               }

    all_int = {**insurance, **claims, **premium}
    print(all_int)

    batchkey_counts = []
    where_condition = " where batchkey='"
    for key, values in all_int.items():
        for value in values:
            contract_ln_count = "select count(*) from fdp.ln_" + key + where_condition + value + "'"
            contract_vl_count = "select count(*) from fdp.vl_" + key + where_condition + value + "'"
            contract_tn_count = "select count(*) from fdp.tn_" + key + where_condition + value + "'"
            contract_st_count = "select count(*) from fdp.st_" + key + where_condition + value + "'"
            batchkey_details = {key:
                {value: {
                    'ln': pd.read_sql_query(contract_ln_count, connection)['count'][0],
                    'vl': pd.read_sql_query(contract_vl_count, connection)['count'][0],
                    'tn': pd.read_sql_query(contract_tn_count, connection)['count'][0],
                    'st': pd.read_sql_query(contract_st_count, connection)['count'][0]}
                }}
            batchkey_counts.append(batchkey_details)

    for key in batchkey_counts:
        print(key)


layerwisecount()
