from datetime import datetime
import calendar
import pandas as pd
import numpy as np
from pandas import ExcelWriter
import glob

fdp_file = ''
fsh_file = ''
for name in glob.glob('./../*FDP*.csv'):
    fdp_file = name
fdp_df_raw = pd.read_csv(fdp_file)
for name in glob.glob('./../*FSH*.csv'):
    fsh_file = name
fsh_df_raw = pd.read_csv(fsh_file)

fdp_df_raw.columns = fdp_df_raw.columns.str.lower()
fsh_df_raw.columns = fsh_df_raw.columns.str.lower()

fdp_df_raw['fdp_policy_number'] = fdp_df_raw['fdp_policy_number'].astype(str)
fsh_df_raw['fsh_policy_number'] = fsh_df_raw['fsh_policy_number'].astype(str)

fdp_df = fdp_df_raw.groupby(['fdp_policy_number'])[['fdp_base_currency_amount']].sum().reset_index()
fsh_df = fsh_df_raw.groupby(['fsh_policy_number'])[['fsh_base_currency_amount']].sum().reset_index()

fdp_unique_policies = len(fdp_df)
fdp_sum_of_amount = fdp_df.fdp_base_currency_amount.sum()
print("Total Number of Policies in FDP = " + str(fdp_unique_policies))
print("Sum of FDP Policy Amounts = " + str(fdp_sum_of_amount))

fsh_unique_policies = len(fsh_df)
fsh_sum_of_amount = fsh_df.fsh_base_currency_amount.sum()
print("Total Number of Policies in FSH = " + str(fsh_unique_policies))
print("Sum of FSH Policy Amounts = " + str(fsh_sum_of_amount))

merged_df = pd.merge(fdp_df, fsh_df, left_on='fdp_policy_number', right_on='fsh_policy_number', how='outer', indicator=True)

print("Number of Matching Polices = " + str(len(merged_df[merged_df['_merge'] == 'both'])))
print("Number of Policies that are in FDP and not in FSH = " + str(len(merged_df[merged_df['_merge'] == 'left_only'])))
print("Number of Policies that are in FSH and not in FDP = " + str(len(merged_df[merged_df['_merge'] == 'right_only'])))

matched_df = merged_df[merged_df['_merge'] == 'both']
print("Sum of the FDP BASE_CURRENCY_AMOUNT of all the policies = " + str(matched_df.fdp_base_currency_amount.sum()))
print("Sum of the FSH BASE_CURRENCY_AMOUNT of all the policies = " + str(matched_df.fsh_base_currency_amount.sum()))

print("Amounts between FDP and FSH Matching Policies = " + str(matched_df.fdp_base_currency_amount.sum() ==
                                                               matched_df.fsh_base_currency_amount.sum()))

matching_percentage = (len(merged_df[merged_df['_merge'] == 'both']) /
                       ((fdp_unique_policies + fsh_unique_policies) / 2)) * 100
print("matching % = " + str(matching_percentage))

matched_df['amount_match'] = np.isclose(
    matched_df['fdp_base_currency_amount'], matched_df['fsh_base_currency_amount'], rtol=0.0001, atol=0.001,
    equal_nan=True)

fdp_missing_df = pd.DataFrame()
fsh_missing_df = pd.DataFrame()
fsh_missing_df['Policies that are in FDP and not in FSH'] = merged_df[merged_df['_merge'] == 'left_only'][
    'fdp_policy_number']
fdp_missing_df['Policies that are in FSH and not in FDP'] = merged_df[merged_df['_merge'] == 'right_only'][
    'fsh_policy_number']

period = fdp_df_raw['fdp_reporting_month'][0]
dt = datetime.strptime(period, '%Y-%m-%d %H:%M:%S')
month = str(calendar.month_name[dt.month])
year = str(dt.year)

details_df = pd.DataFrame(columns=['key', 'value']).astype(str)
details_df = details_df.append({'key': 'Source', 'value': fdp_df_raw['fdp_source'][0]}, ignore_index=True)
details_df = details_df.append({'key': 'Reporting period', 'value': month + '-' + year}, ignore_index=True)
details_df = details_df.append({'key': 'Total Number of Policies in FDP', 'value': str(fdp_unique_policies)},
                               ignore_index=True)
details_df = details_df.append({'key': 'Sum of FDP Policy Amounts', 'value': str(fdp_sum_of_amount)}, ignore_index=True)
details_df = details_df.append({'key': 'Total Number of Policies in FSH', 'value': str(fsh_unique_policies)},
                               ignore_index=True)
details_df = details_df.append({'key': 'Sum of FSH Policy Amounts', 'value': str(fsh_sum_of_amount)}, ignore_index=True)
details_df = details_df.append(
    {'key': 'Number of Matching Polices', 'value': str(len(merged_df[merged_df['_merge'] == 'both']))},
    ignore_index=True)
details_df = details_df.append({'key': 'Number of Policies that are in FDP and not in FSH',
                                'value': str(len(merged_df[merged_df['_merge'] == 'left_only']))}, ignore_index=True)
details_df = details_df.append({'key': 'Number of Policies that are in FSH and not in FDP',
                                'value': str(len(merged_df[merged_df['_merge'] == 'right_only']))}, ignore_index=True)
details_df = details_df.append({'key': 'Amounts between FDP and FSH Matching Policies',
                                'value': str(matched_df.fdp_base_currency_amount.sum() ==
                                             matched_df.fsh_base_currency_amount.sum())}, ignore_index=True)
details_df = details_df.append({'key': 'matching percentage', 'value': str(matching_percentage)}, ignore_index=True)

filename = ".//..//FSH_FDP_" + fdp_df_raw['fdp_source'][0] + "_" + month + '-' + year + ".xlsx"
with ExcelWriter(filename) as writer:
    details_df.to_excel(writer, index=False, sheet_name='Summary')
    for column in details_df:
        column_width = max(details_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = details_df.columns.get_loc(column)
        writer.sheets['Summary'].set_column(col_idx, col_idx, column_width)
    fdp_missing_df.to_excel(writer, index=False, sheet_name='FDP missing policies')
    for column in fdp_missing_df:
        column_width = max(fdp_missing_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = fdp_missing_df.columns.get_loc(column)
        writer.sheets['FDP missing policies'].set_column(col_idx, col_idx, column_width)
    fsh_missing_df.to_excel(writer, index=False, sheet_name='FSH missing policies')
    for column in fsh_missing_df:
        column_width = max(fsh_missing_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = fsh_missing_df.columns.get_loc(column)
        writer.sheets['FSH missing policies'].set_column(col_idx, col_idx, column_width)
    matched_df.to_excel(writer, index=False, sheet_name='Amounts comparison')
    for column in matched_df:
        column_width = max(matched_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = matched_df.columns.get_loc(column)
        writer.sheets['Amounts comparison'].set_column(col_idx, col_idx, column_width)

print(details_df)
