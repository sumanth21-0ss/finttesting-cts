import pandas as pd
from pandas import ExcelWriter

fsh_df = pd.read_excel(open('C:\\Hemanth\\premium\\reconciliation\\FSH_ALL_IN_ONE.xlsx', 'rb'), sheet_name='Sheet1')

print("total fsh count = "+ str(len(fsh_df)))

fsh_df.drop(fsh_df[fsh_df.Future == False].index, inplace=True)

print("total fsh count after removing false future flag = "+ str(len(fsh_df)))

fsh_df_grouped = fsh_df.groupby('POL_NUM')['UEPR'].sum().reset_index()

print("total fsh after grouping = "+ str(len(fsh_df_grouped)))



fdp_df = pd.read_csv('C:\\Hemanth\\premium\\reconciliation\\FDP_EVO_2020108_Automation_check_v1.csv')

print("total fdp count = "+ str(len(fdp_df)))


fdp_df_grouped = fdp_df.groupby('insurancecontractidentifier')['grossunearnedpremiumfunctionalamount'].sum().reset_index()

print("total fdp count after grouping = "+ str(len(fdp_df_grouped)))


merged_df = fsh_df_grouped.merge(fdp_df_grouped, left_on='POL_NUM', right_on='insurancecontractidentifier', how='inner')

print("fdp and fsh matching policies = " + str(len(merged_df)))

merged_df['compare'] = abs(merged_df['UEPR'] - (merged_df['grossunearnedpremiumfunctionalamount'])) < 1e-9

path = "C:\\Hemanth\\premium\\reconciliation\\output.xlsx"
merged_df.to_excel(path)

merged_df_outer = pd.merge(fsh_df_grouped, fdp_df_grouped, left_on='POL_NUM', right_on='insurancecontractidentifier', how='outer', indicator=True)
print("Number of Policies that are in FSH and not in FDP = " + str(len(merged_df_outer[merged_df_outer['_merge'] == 'left_only'])))
print("Number of Policies that are in FDP and not in FSH = " + str(len(merged_df_outer[merged_df_outer['_merge'] == 'right_only'])))


fsh_only_df = merged_df_outer[merged_df_outer['_merge'] == 'left_only']
fdp_only_df = merged_df_outer[merged_df_outer['_merge'] == 'right_only']

fsh_only_df.to_excel(path, sheet_name="policies available only in fsh")
fdp_only_df.to_excel(path, sheet_name="policies available only in fdp")


filename = path
with ExcelWriter(filename, engine="xlsxwriter") as writer:
    merged_df.to_excel(writer, index=False, sheet_name='Summary')
    for column in merged_df:
        column_width = max(merged_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = merged_df.columns.get_loc(column)
        writer.sheets['Summary'].set_column(col_idx, col_idx, column_width)
    fsh_only_df.to_excel(writer, index=False, sheet_name='FDP missing policies')
    for column in fsh_only_df:
        column_width = max(fsh_only_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = fsh_only_df.columns.get_loc(column)
        writer.sheets['FDP missing policies'].set_column(col_idx, col_idx, column_width)
    fdp_only_df.to_excel(writer, index=False, sheet_name='FSH missing policies')
    for column in fdp_only_df:
        column_width = max(fdp_only_df[column].astype(str).map(len).max(), len(column)) + 2
        col_idx = fdp_only_df.columns.get_loc(column)
        writer.sheets['FSH missing policies'].set_column(col_idx, col_idx, column_width)
