import secrets
import gc
import pandas as pd
import string
import os
from datetime import datetime

file_path = 'C:\\LargeVolumeOutput\\'

folder = datetime.now().strftime('%Y-%m-%d')

record_type = 'Duplicate'

initial_record = 20

loop_value = 5

if initial_record == 50 or initial_record == 20:
    os.mkdir(file_path + folder)

file_path = file_path + folder + '\\'

generated_record = initial_record * loop_value

os.mkdir(file_path+str(generated_record))

master_path = os.getcwd() + '\\OrderedLargeVolumeMasterSet\\'

if record_type == 'Duplicate':
    master_path = os.getcwd() + '\\OrderedLargeVolume' + record_type + 'MasterSet\\'


def read_data(integration_name):
    """
    Read master set csv files for all integartions based on initial record count
    for eg initial_record = 50 to read duplicate set and initial_record = 20 to read unique set
    :param integration_name: integration_name
    :return: data_df
    """
    path = file_path + str(initial_record) + '\\'
    if initial_record == 50 or initial_record == 20:
        path = master_path
    data_df = pd.read_csv(path + integration_name + '_' + str(initial_record) + '.csv')
    return data_df


def create_dataset(dataframe, integration_name, i=''):
    """
    write csv file for the integrations with parts of manipulated data
    :param dataframe: dataframe
    :param integration_name: integration_name
    :param i: parts of data
    """
    path = file_path + str(generated_record) + '\\'
    dataframe.to_csv(path + integration_name + '_' + str(generated_record) + i + '.csv', index=False)


def merge_data(integration_name, dataframe):
    """
    Read the parts of integartion data and merge them into single dataframe for each type of integration files
    :param dataframe: dataframe
    :param integration_name: integration_name
    :param i: parts of data
    :return: dataframe
    """
    path = file_path + str(generated_record) + '\\'
    for _ in range(loop_value):
        data_df = pd.read_csv(path + integration_name + '_' + str(generated_record) + '_' + str(_) + '.csv')
        if 'claim' in integration_name:
            data_df['non_eligible'] = data_df['non_eligible'].astype("Int64")
        if integration_name == 'claim_peril':
            data_df['recovery_type_id'] = data_df['recovery_type_id'].fillna("NA")
        dataframe = dataframe.append(data_df, ignore_index=True)
        os.remove(path + integration_name + '_' + str(generated_record) + '_' + str(_) + '.csv')
    return dataframe


def generate_data(integration_name, dataframe):
    """
    create csv file for each integration files from the merged dataframe
    :param dataframe: dataframe
    :param integration_name: integration_name
    """
    dataframe = merge_data(integration_name, dataframe)
    create_dataset(dataframe, integration_name)
    print('Generated - ' + integration_name)


def manipulate_test_data():
    """
    Create large volume csv files for each type of integration files based on unique/duplicate set
    Final Record size is calculated using initial record count * loop value count
    """
    df_policy = pd.DataFrame()
    df_product = pd.DataFrame()
    df_object = pd.DataFrame()

    df_claim = pd.DataFrame()
    df_claim_peril = pd.DataFrame()
    df_claim_payment = pd.DataFrame()

    df_premium = pd.DataFrame()

    for _ in range(loop_value):
        print(_)
        temp_df_policy = read_data('insurance_contract_policy_details')
        temp_df_product = read_data('insurance_product_details')
        temp_df_object = read_data('insured_object')

        temp_df_claim = read_data('claim')
        temp_df_claim_peril = read_data('claim_peril')
        temp_df_claim_payment = read_data('claim_payment')

        temp_df_premium = read_data('gross_written_premium_transactions')

        temp_df_claim['non_eligible'] = temp_df_claim['non_eligible'].astype("Int64")
        temp_df_claim_peril['non_eligible'] = temp_df_claim_peril['non_eligible'].astype("Int64")
        temp_df_claim_peril['recovery_type_id'] = temp_df_claim_peril['recovery_type_id'].fillna("NA")
        temp_df_claim_payment['non_eligible'] = temp_df_claim_payment['non_eligible'].astype("Int64")

        # create a lookup table for the relationship columns
        temp_df_insurance_id_lookup = temp_df_policy[['insurance_contract_id']].copy()
        temp_df_claim_id_lookup = temp_df_claim[['claim_id']].copy()
        temp_df_claim_transaction_id_lookup = temp_df_claim_peril[['claim_transaction_id']].copy()
        temp_df_claim_payment_id_lookup = temp_df_claim_payment[['claim_payment_id']].copy()

        random_str = ''.join(secrets.choice(string.ascii_lowercase) for _ in range(3))

        # add a new column with random characters added to the relationsip columns
        temp_df_insurance_id_lookup['insurance_contract_id_random'] = temp_df_insurance_id_lookup. \
            assign(insurance_contract_id=lambda x, value=random_str: x.insurance_contract_id + value)
        temp_df_insurance_id_lookup = temp_df_insurance_id_lookup.drop_duplicates(subset=['insurance_contract_id'])
        temp_df_policy['insurance_contract_id'] = temp_df_policy['insurance_contract_id']. \
            map(temp_df_insurance_id_lookup.set_index('insurance_contract_id')['insurance_contract_id_random'])
        temp_df_product['insurance_contract_id'] = temp_df_product['insurance_contract_id']. \
            map(temp_df_insurance_id_lookup.set_index('insurance_contract_id')['insurance_contract_id_random'])
        temp_df_object['insurance_contract_id'] = temp_df_object['insurance_contract_id']. \
            map(temp_df_insurance_id_lookup.set_index('insurance_contract_id')['insurance_contract_id_random'])

        temp_df_claim['insurance_contract_id'] = temp_df_claim['insurance_contract_id']. \
            map(temp_df_insurance_id_lookup.set_index('insurance_contract_id')['insurance_contract_id_random'])

        temp_df_premium['insurance_contract_id'] = temp_df_premium['insurance_contract_id']. \
            map(temp_df_insurance_id_lookup.set_index('insurance_contract_id')['insurance_contract_id_random'])

        del temp_df_insurance_id_lookup
        gc.collect()

        temp_df_claim_id_lookup['claim_id_random'] = temp_df_claim_id_lookup. \
            assign(claim_id=lambda x, value=random_str: x.claim_id + value)
        temp_df_claim_id_lookup = temp_df_claim_id_lookup.drop_duplicates(subset=['claim_id'])
        temp_df_claim['claim_id'] = temp_df_claim['claim_id']. \
            map(temp_df_claim_id_lookup.set_index('claim_id')['claim_id_random'])
        temp_df_claim_peril['claim_id'] = temp_df_claim_peril['claim_id']. \
            map(temp_df_claim_id_lookup.set_index('claim_id')['claim_id_random'])
        temp_df_claim_payment['claim_id'] = temp_df_claim_payment['claim_id']. \
            map(temp_df_claim_id_lookup.set_index('claim_id')['claim_id_random'])

        del temp_df_claim_id_lookup
        gc.collect()

        temp_df_claim_transaction_id_lookup['claim_transaction_id_random'] = temp_df_claim_transaction_id_lookup. \
            assign(claim_transaction_id=lambda x, value=random_str: x.claim_transaction_id + value)
        temp_df_claim_transaction_id_lookup = temp_df_claim_transaction_id_lookup.drop_duplicates(
            subset=['claim_transaction_id'])
        temp_df_claim_peril['claim_transaction_id'] = temp_df_claim_peril['claim_transaction_id']. \
            map(temp_df_claim_transaction_id_lookup.set_index('claim_transaction_id')['claim_transaction_id_random'])
        temp_df_claim_payment['claim_transaction_id'] = temp_df_claim_payment['claim_transaction_id']. \
            map(temp_df_claim_transaction_id_lookup.set_index('claim_transaction_id')['claim_transaction_id_random'])

        del temp_df_claim_transaction_id_lookup
        gc.collect()

        temp_df_claim_payment_id_lookup['claim_payment_id_random'] = temp_df_claim_payment_id_lookup. \
            assign(claim_payment_id=lambda x, value=random_str: x.claim_payment_id + value)
        temp_df_claim_payment_id_lookup = temp_df_claim_payment_id_lookup.drop_duplicates(subset=['claim_payment_id'])
        temp_df_claim_payment['claim_payment_id'] = temp_df_claim_payment['claim_payment_id']. \
            map(temp_df_claim_payment_id_lookup.set_index('claim_payment_id')['claim_payment_id_random'])

        del temp_df_claim_payment_id_lookup
        gc.collect()

        create_dataset(temp_df_policy, 'insurance_contract_policy_details', '_' + str(_))
        del temp_df_policy
        gc.collect()

        create_dataset(temp_df_product, 'insurance_product_details', '_' + str(_))
        del temp_df_product
        gc.collect()

        create_dataset(temp_df_object, 'insured_object', '_' + str(_))
        del temp_df_object
        gc.collect()

        create_dataset(temp_df_claim, 'claim', '_' + str(_))
        del temp_df_claim
        gc.collect()

        create_dataset(temp_df_claim_peril, 'claim_peril', '_' + str(_))
        del temp_df_claim_peril
        gc.collect()

        create_dataset(temp_df_claim_payment, 'claim_payment', '_' + str(_))
        del temp_df_claim_payment
        gc.collect()

        create_dataset(temp_df_premium, 'gross_written_premium_transactions', '_' + str(_))
        del temp_df_premium
        gc.collect()

    print('Generating-' + str(generated_record) + ' Records')

    generate_data('insurance_contract_policy_details', df_policy)
    del df_policy
    gc.collect()

    generate_data('insurance_product_details', df_product)
    del df_product
    gc.collect()

    generate_data('insured_object', df_object)
    del df_object
    gc.collect()

    generate_data('claim', df_claim)
    del df_claim
    gc.collect()

    generate_data('claim_peril', df_claim_peril)
    del df_claim_peril
    gc.collect()

    generate_data('claim_payment', df_claim_payment)
    del df_claim_payment
    gc.collect()

    generate_data('gross_written_premium_transactions', df_premium)
    del df_premium
    gc.collect()

    print('Generated path - ' + file_path + '\\' + str(generated_record))


manipulate_test_data()
