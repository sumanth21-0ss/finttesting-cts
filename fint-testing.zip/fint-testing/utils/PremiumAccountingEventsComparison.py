import pandas as pd
import numpy as np
import psycopg2
import glob
fail = 0


def read_data(filename, file_path):
    """
    Read master set csv files for all integartions based on initial record count
    for eg initial_record = 50 to read duplicate set and initial_record = 20 to read unique set
    :param integration_name: integration_name
    :return: data_df
    """
    if filename =='XlaTrxL':
        data_df = pd.read_csv(glob.glob(file_path + filename + '*')[0],converters = {'SOURCE_ICO': lambda x: str(x)})
        data_df = data_df.replace(np.nan, '', regex=True)
        data_df['FSH_PRODUCT'] = data_df.FSH_PRODUCT.replace('', 0).astype('int64')
        data_df.sort_values(by=['TRANSACTION_NUMBER', 'FSH_PRODUCT', 'FSH_CHANNEL'])
    else:
        data_df = pd.read_csv(glob.glob(file_path+filename+'*')[0])
        data_df = data_df.replace(np.nan, '', regex=True)
        data_df.sort_values(by=['TRANSACTION_NUMBER'])

    return data_df


def read_query(filename, scenario):
    if filename=='XlaTrxH':
        temp_df = scenario['header']
        temp_df = temp_df.replace(np.nan, '', regex=True)
    else:
        temp_df = scenario['line']
        temp_df = temp_df.replace(np.nan, '', regex=True)
        temp_df['productidentifier'] = temp_df.productidentifier.replace('', 0).astype('int64')
    return temp_df


def generate_report(filename, records, fail_records, reportfolder):
    if filename == 'XlaTrxH':
        report_name='Accounting_report_Transcationheader'
    else:
        report_name = 'Accounting_report_Transcationline'
    html_file = open(reportfolder + '/'+report_name +'.html', 'w')
    html_file.write(records.to_html(classes='w3-table-all'))
    html_file.close()
    if not fail_records.empty:
        global fail
        fail = 1
        html_file = open(reportfolder + '/Failed_'+report_name +'.html', 'w')
        html_file.write(fail_records.to_html(classes='w3-table-all'))
        html_file.close()


def compare_header(records):
    records['Compare_TRANSACTION_TYPE'] = np.where(
        records['TRANSACTION_TYPE'] ==records['transactiontype'],
        True, False)
    records['compare_TRANSACTION_DATE'] = np.where(
        records['TRANSACTION_DATE'] == records['transactiondate'],
        True, False)
    records['compare_TRANSACTION_NUMBER'] = np.where(
        records['TRANSACTION_NUMBER'] == records['transactionidentifier'],
        True, False)
    records['compare_FDP_BATCH_KEY'] = np.where(
        records['FDP_BATCH_KEY'] == records['metadatabatchidentifier'],
        True, False)
    records['Compare_LEDGER_NAME'] = np.where(
        records['LEDGER_NAME'] == records['ledgername'],
        True, False)
    records['compare_POSTING_FLAG'] = np.where(
        records['POSTING_FLAG'] == records['postingflag'],
        True, False)
    records['compare_AHCS_EVENT_CODE'] = np.where(
        records['AHCS_EVENT_CODE'] == records['ahcseventcode'],
        True, False)
    records['Compare_FSH_SOURCE'] = np.where(
        records['FSH_SOURCE'] == records['systemidentifier'],
        True, False)
    records['compare_UNDERWRITER'] = np.where(
        records['UNDERWRITER'] == records['underwriteridentifier'],
        True, False)
    records['legalentityidentifier'] = records['legalentityidentifier'].astype(np.int64)
    records['compare_SOURCE_LE'] = np.where(
        records['SOURCE_LE'] == records['legalentityidentifier'],
        True, False)
    records['compare_TRANSACTION_SUBTYPE'] = np.where(
        records['TRANSACTION_SUBTYPE'] == records['subtype'],
        True, False)
    records['compare_TRANSACTION_REASON'] = np.where(
        records['TRANSACTION_REASON'] == records['reason'],
        True, False)

    records['Overall'] = records['Compare_TRANSACTION_TYPE'] & records['compare_TRANSACTION_DATE'] \
                              & records['compare_TRANSACTION_NUMBER'] & records['compare_FDP_BATCH_KEY'] \
                              & records['Compare_LEDGER_NAME'] & records['compare_POSTING_FLAG'] \
                              & records['compare_AHCS_EVENT_CODE'] & records['Compare_FSH_SOURCE'] \
                              & records['compare_UNDERWRITER'] & records['compare_SOURCE_LE']

    fail_records = records.loc[(records['Overall'] == False)]

    return records, fail_records


def compare_line(records):
    records['compare_TRANSACTION_NUMBER'] = np.where(
        records['TRANSACTION_NUMBER'] == records['transactionidentifier'],
        True, False)
    records['compare_BASE_AMOUNT'] = np.where(
        records['BASE_AMOUNT'] == records['functionalamount'],
        True, False)
    records['Compare_CURRENCY_CODE'] = np.where(
        records['CURRENCY_CODE'] == records['transactionalcurrencycode'],
        True, False)
    records['compare_ORIGINAL_AMOUNT'] = np.where(
        records['ORIGINAL_AMOUNT'] == records['transactionalamount'],
        True, False)
    records['compare_FSH_BRAND'] = np.where(
        records['FSH_BRAND'] == records['brandidentifier'],
        True, False)
    records['Compare_FSH_CHANNEL'] = np.where(
        records['FSH_CHANNEL'] == records['channelidentifier'],
        True, False)
    records['Compare_FSH_PRODUCT'] = np.where(
        records['FSH_PRODUCT'] == records['productidentifier'],
        True, False)
    records['compare_SOURCE_ICO'] = np.where(
        records['SOURCE_ICO'] == records['sourceico'],
        True, False)
    records['Compare_FINANCIAL_ELEMENT'] = np.where(
        records['FINANCIAL_ELEMENT'] == records['financialelement'],
        True, False)

    records['Overall'] = records['compare_TRANSACTION_NUMBER'] & records['compare_BASE_AMOUNT'] \
                                          & records['Compare_CURRENCY_CODE'] & records['Compare_CURRENCY_CODE'] \
                                          & records['compare_FSH_BRAND'] & records['Compare_FSH_CHANNEL'] \
                                          & records['Compare_FSH_PRODUCT'] & records['compare_SOURCE_ICO'] \
                                          & records['Compare_FINANCIAL_ELEMENT']

    fail_records = records.loc[(records['Overall'] == False)]

    return records, fail_records


def compare_records(filename, records):
    if filename=='XlaTrxH':
        return compare_header(records)
    else:
        return compare_line(records)


def merge_dataframe(filename, file_df, expected_df):
    if filename == 'XlaTrxH':
        return pd.merge(file_df, expected_df, how='outer', left_on=['TRANSACTION_NUMBER'],
                           right_on=['transactionidentifier'], indicator=True)
    else:
        return pd.merge(file_df, expected_df, how='outer', left_on=['TRANSACTION_NUMBER','FSH_PRODUCT','FSH_BRAND','FSH_CHANNEL','BASE_AMOUNT'],
                           right_on=['transactionidentifier','productidentifier','brandidentifier','channelidentifier','functionalamount'], indicator=True)


def compare_file_and_data(scenario, reportfolder):
    files = ['XlaTrxL', 'XlaTrxH']
    for file in files:
        file_df = read_data(file, scenario['filepath'])
        expected_df = read_query(file,scenario)
        records = merge_dataframe(file, file_df, expected_df)
        records, fail_records = compare_records(file, records)
        generate_report(file, records, fail_records, reportfolder)
    if fail == 1:
        assert False

