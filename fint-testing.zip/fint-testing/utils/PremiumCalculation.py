import pandas as pd
import datetime as dt
import numpy as np
from decimal import Decimal, ROUND_HALF_UP


pd.set_option('display.width', 200)
pd.set_option('display.max_columns', 10)


def calculate_start_date(onriskdate, transactiondate):
    """
    Calculate starting date for the records
    :param onriskdate: onriskdate
    :param transactiondate: transactiondate
    :return: start_date
    """
    if onriskdate < transactiondate:
        start_date = onriskdate
    else:
        start_date = transactiondate
    return start_date


def calculate_start_range(startdate, offriskdate):
    """
    Calculate start date range for the records
    :param startdate: startdate
    :param offriskdate: offriskdate
    :return:  x as month start range
    """
    day = startdate.day
    if day == 1:
        x = pd.date_range(start=startdate, end=offriskdate, freq='MS')
    else:
        x = pd.date_range(start=startdate - pd.offsets.MonthBegin(1), end=offriskdate, freq='MS')
    return x


def calculate_end_range(startdate, offriskdate):
    """
    Calculate end date range for the records
    :param startdate: startdate
    :param offriskdate: offriskdate
    :return:  y as month end range
    """
    y = pd.date_range(start=startdate, end=offriskdate, freq='M')
    return y


def split_records(d, start_len, end_len, onriskdate, offriskdate, start_range, end_range):
    dataframe = pd.DataFrame(data=d)
    dataframe = pd.concat([dataframe] * max(start_len, end_len), ignore_index=True)

    if start_len < end_len:
        start_range = start_range.union(pd.to_datetime([onriskdate]) - pd.offsets.MonthBegin(1))
    elif end_len < start_len:
        end_range = end_range.union(pd.to_datetime([offriskdate]) + pd.offsets.MonthEnd(1))

    start_range_list = start_range.tolist()
    end_range_list = end_range.tolist()
    column_position = len(dataframe.columns)
    dataframe.insert((column_position - 1), column="Monthstart", value=start_range_list)
    dataframe.insert(column_position, column="Monthend", value=end_range_list)
    return dataframe


def calculate_unearned_and_earned_amounts(grosswrittenpremiumtransactionsurrogatekey, insuranceproductsurrogatekey, transactiondate, onriskdate,
                                          offriskdate, functionalcurrencycodeidentifier, transactionalcurrencycodeidentifier,
                                          grosswrittenpremiumamount, uprcalculationflag, grosswrittenpremiumtransactiontypeidentifier,
                                          start_date, start_range, end_range):
    """
    multiple records are created based on start and end range and calculate unearned and earned amounts
    :param grosswrittenpremiumtransactionsurrogatekey: grosswrittenpremiumtransactionsurrogatekey
    :param insuranceproductsurrogatekey: insuranceproductsurrogatekey
    :param transactiondate: transactiondate
    :param onriskdate: onriskdate
    :param offriskdate: offriskdate
    :param functionalcurrencycodeidentifier: functionalcurrencycodeidentifier
    :param transactionalcurrencycodeidentifier: transactionalcurrencycodeidentifier
    :param grosswrittenpremiumamount: grosswrittenpremiumamount
    :param uprcalculationflag: uprcalculationflag
    :param grosswrittenpremiumtransactiontypeidentifier: grosswrittenpremiumtransactiontypeidentifier
    :param start_date: start_date
    :param start_range: start_range
    :param end_range: end_range
    :return: unearned_amount, earned_amount
    """
    start_len = len(start_range)
    end_len = len(end_range)
    d = {'grosswrittenpremiumtransactionsurrogatekey': [grosswrittenpremiumtransactionsurrogatekey],
         'insuranceproductsurrogatekey': [insuranceproductsurrogatekey],
         'transactiondate': [transactiondate],
         'onriskdate': [onriskdate],
         'offriskdate': [offriskdate],
         'functionalcurrencycodeidentifier': [functionalcurrencycodeidentifier],
         'transactionalcurrencycodeidentifier': [transactionalcurrencycodeidentifier],
         'grosswrittenpremiumamount': [grosswrittenpremiumamount],
         'uprcalculationflag': [uprcalculationflag],
         'grosswrittenpremiumtransactiontypeidentifier': [grosswrittenpremiumtransactiontypeidentifier],
         'start_date': [start_date],
         'start_range': [start_range],
         'end_range': [end_range]}

    dataframe = split_records(d, start_len, end_len, onriskdate, offriskdate, start_range, end_range)

    dataframe['Monthstart'] = pd.to_datetime(dataframe['Monthstart']).dt.date
    dataframe['Monthend'] = pd.to_datetime(dataframe['Monthend']).dt.date
    dataframe['Automation_UEPAmount'] = np.vectorize(calculate_unearned_amount, otypes=[float])(
        dataframe['uprcalculationflag'],
        dataframe['grosswrittenpremiumamount'], dataframe['onriskdate'],
        dataframe['Monthend'], dataframe['grosswrittenpremiumtransactiontypeidentifier'],
        dataframe['offriskdate'])
    dataframe['Automation_EPAmount'] = dataframe['grosswrittenpremiumamount'] - \
                                       dataframe['Automation_UEPAmount']
    dataframe['Automation_EPAmount'][1:] = dataframe['Automation_EPAmount'][1:] - \
                                           dataframe['Automation_EPAmount'][1:]. \
                                               shift(1, fill_value=dataframe['Automation_EPAmount'][0])
    unearned_amount = round(dataframe['Automation_UEPAmount'].sum(), 2)
    earned_amount = round(dataframe['Automation_EPAmount'].sum(), 2)
    return unearned_amount, earned_amount


def calculate_unearned_amount(uprcalculationflag, grosswrittenpremiumamount, onriskdate, monthend,
                              grosswrittenpremiumtransactiontypeidentifier, offriskdate):
    """
    Calculate unearned premium amount for transactional and functional amount
    :param uprcalculationflag: uprcalculationflag
    :param grosswrittenpremiumamount: grosswrittenpremiumamount
    :param onriskdate: onriskdate
    :param monthend: monthend
    :param grosswrittenpremiumtransactiontypeidentifier: grosswrittenpremiumtransactiontypeidentifier
    :param offriskdate: offriskdate
    :return:uep_amount
    """
    upr = uprcalculationflag
    grosswp = grosswrittenpremiumamount
    if upr == "E":
        uep_amount = 0
    elif upr == "I" and onriskdate > monthend:
        uep_amount = grosswp
    elif upr == "I" and offriskdate <= monthend:
        uep_amount = 0
    else:
        uep_amount = grosswp * (offriskdate - monthend) / (
                (offriskdate - onriskdate) + dt.timedelta(days=1))
    uep_amount = Decimal(str(Decimal(str(uep_amount)).quantize(Decimal('0.000001'), ROUND_HALF_UP)))\
        .quantize(Decimal('0.01'), ROUND_HALF_UP)
    return uep_amount


def calculate_sum_of_unearned_and_earned_amounts(master_df):
    """
    Vectorised method call to calculate sum of earned and unearned premium amount for transactional and functional amount
    :param master_df: master_df
    :return:master_df
    """
    master_df['sum_Automation_UEPTransactionalAmount'], master_df['sum_Automation_EPTransactionalAmount'] = \
        np.vectorize(calculate_unearned_and_earned_amounts)(master_df['grosswrittenpremiumtransactionsurrogatekey'],
                                                            master_df['insuranceproductsurrogatekey'],
                                                            master_df['transactiondate'],
                                                            master_df['onriskdate'],
                                                            master_df['offriskdate'],
                                                            master_df['functionalcurrencycodeidentifier'],
                                                            master_df['transactionalcurrencycodeidentifier'],
                                                            master_df['grosswrittenpremiumtransactionalamount'],
                                                            master_df['uprcalculationflag'],
                                                            master_df['grosswrittenpremiumtransactiontypeidentifier'],
                                                            master_df['start_date'],
                                                            master_df['start_range'],
                                                            master_df['end_range'])
    master_df['sum_Automation_UEPFunctionalAmount'], master_df['sum_Automation_EPFunctionalAmount'] = \
        np.vectorize(calculate_unearned_and_earned_amounts)(master_df['grosswrittenpremiumtransactionsurrogatekey'],
                                                            master_df['insuranceproductsurrogatekey'],
                                                            master_df['transactiondate'],
                                                            master_df['onriskdate'],
                                                            master_df['offriskdate'],
                                                            master_df['functionalcurrencycodeidentifier'],
                                                            master_df['transactionalcurrencycodeidentifier'],
                                                            master_df['grosswrittenpremiumfunctionalamount'],
                                                            master_df['uprcalculationflag'],
                                                            master_df['grosswrittenpremiumtransactiontypeidentifier'],
                                                            master_df['start_date'],
                                                            master_df['start_range'],
                                                            master_df['end_range'])


def test_premium_calculation(scenario, reportfolder):
    """
    Main method to compare calculated sum of earned and unearned aoumnt with the sum of earned and unearned values in
    transformatio table and generates html reports for all record set and separate report for comparison failed records
    :param scenario: scenario
    :param reportfolder: reportfolder
    :return:master_df
    """
    master_df = pd.read_sql_query(scenario['master_df_query'], scenario['connection'])

    master_df['onriskdate'] = pd.to_datetime(master_df['onriskdate']).dt.date
    master_df['offriskdate'] = pd.to_datetime(master_df['offriskdate']).dt.date
    master_df['transactiondate'] = pd.to_datetime(master_df['transactiondate']).dt.date

    master_df['start_date'] = np.vectorize(calculate_start_date)(master_df['onriskdate'], master_df['transactiondate'])
    master_df['start_range'] = np.vectorize(calculate_start_range, otypes=[pd.DatetimeIndex])(master_df['start_date'],
                                                                                              master_df['offriskdate'])
    master_df['end_range'] = np.vectorize(calculate_end_range, otypes=[pd.DatetimeIndex])(master_df['start_date'],
                                                                                          master_df['offriskdate'])
    calculate_sum_of_unearned_and_earned_amounts(master_df)

    columns = ['sum_Automation_UEPTransactionalAmount', 'sum_Automation_EPTransactionalAmount',
               'sum_Automation_UEPFunctionalAmount', 'sum_Automation_EPFunctionalAmount']

    for col in columns:
        master_df = master_df.round({col: 2})

    tn_dataframe = pd.read_sql_query(scenario['tn_df_query'], scenario['connection'])

    records = pd.merge(master_df, tn_dataframe, how='outer', left_on='grosswrittenpremiumtransactionsurrogatekey',
                       right_on='grosswrittenpremiumtransactionsurrogatekey', indicator=True)

    records['Auto_vs_tn_GEPTxAmount'] = np.where(
        records['sum_Automation_EPTransactionalAmount'] == records['tn_sum_grossearnedpremiumtransactionalamount'],
        'True', 'False')
    records['Auto_vs_tn_GEPFxAmount'] = np.where(
        records['sum_Automation_EPFunctionalAmount'] == records['tn_sum_grossearnedpremiumfunctionalamount'],
        'True', 'False')
    records['Auto_vs_tn_GUEPTxAmount'] = np.where(
        records['sum_Automation_UEPTransactionalAmount'] == records['tn_sum_grossunearnedpremiumtransactionalamount'],
        'True', 'False')
    records['Auto_vs_tn_GUEPFxAmount'] = np.where(
        records['sum_Automation_UEPFunctionalAmount'] == records['tn_sum_grossunearnedpremiumfunctionalamount'],
        'True', 'False')

    html_file = open(reportfolder + '/premiumcalculation_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + '.html', 'w')
    html_file.write(records.to_html(classes='w3-table-all'))
    html_file.close()

    fail_records = records.loc[(records['Auto_vs_tn_GEPTxAmount'] == 'False') |
                               (records['Auto_vs_tn_GEPFxAmount'] == 'False') |
                               (records['Auto_vs_tn_GUEPTxAmount'] == 'False') |
                               (records['Auto_vs_tn_GUEPFxAmount'] == 'False')]

    if not fail_records.empty:
        html_file = open(
            reportfolder + '/FailedRecords_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + '.html', 'w')
        html_file.write(fail_records.to_html(classes='w3-table-all'))
        html_file.close()
        assert False
