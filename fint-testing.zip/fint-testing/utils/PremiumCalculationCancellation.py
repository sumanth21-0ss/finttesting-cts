import pandas as pd
import numpy as np
from decimal import Decimal, ROUND_HALF_UP
from pandas import ExcelWriter
from utils.PremiumCalculation import calculate_start_date, calculate_start_range, calculate_end_range, split_records


pd.set_option('display.width', 200)
pd.set_option('display.max_columns', 10)


def calculate_unearned_and_earned_amounts(scenario,grosswrittenpremiumtransactionidentifier,transactiondate, onriskdate,
                                          offriskdate, insuranceproductsurrogatekey, productidentifier,
                                          grosswrittenpremiumfunctionalamount, grosswrittenpremiumtransactionalamount,
                                          start_date, start_range, end_range,insurancecontractidentifier):
    """
    multiple records are created based on start and end range
    unearned is calculated using (sum of unearned amount of the calendar month)*-1 for inception
    and cancellation records for the same insurancecontractid
    earned is calculated using (sum of GWP amount of the calendar month) - Sum of earned amount of previous calendar months
    :param scenario: scenario
    :param grosswrittenpremiumtransactionidentifier: grosswrittenpremiumtransactionidentifier
    :param transactiondate: transactiondate
    :param onriskdate: onriskdate
    :param offriskdate: offriskdate
    :param insuranceproductsurrogatekey: insuranceproductsurrogatekey
    :param productidentifier: productidentifier
    :param grosswrittenpremiumfunctionalamount: grosswrittenpremiumfunctionalamount
    :param grosswrittenpremiumtransactionalamount: grosswrittenpremiumtransactionalamount
    :param start_date: start_date
    :param start_range: start_range
    :param end_range: end_range
    :param insurancecontractidentifier: insurancecontractidentifier
    :return: unearned_amount_funct, unearned_amount_trans, earned_amount_funct, earned_amount_trans
    """
    start_len = len(start_range)
    end_len = len(end_range)
    d = {'grosswrittenpremiumtransactionidentifier': [grosswrittenpremiumtransactionidentifier],
         'transactiondate': [transactiondate],
         'onriskdate': [onriskdate],
         'offriskdate': [offriskdate],
         'insuranceproductsurrogatekey': [insuranceproductsurrogatekey],
         'productidentifier': [productidentifier],
         'grosswrittenpremiumfunctionalamount': [grosswrittenpremiumfunctionalamount],
         'grosswrittenpremiumtransactionalamount': [grosswrittenpremiumtransactionalamount],
         'start_date': [start_date],
         'start_range': [start_range],
         'end_range': [end_range],
         'insurancecontractidentifier': [insurancecontractidentifier]}

    dataframe = split_records(d, start_len, end_len, onriskdate, offriskdate, start_range, end_range)

    dataframe['calendarmonthidentiifer'] = dataframe['Monthstart'].apply(lambda x: x.strftime('%Y%m'))
    if dataframe['grosswrittenpremiumfunctionalamount'][0] != 0.0:
        unearned_query = scenario['unearned'].replace('inscont', dataframe['insurancecontractidentifier'][0])\
            .replace('transid', str(dataframe['transactiondate'][0]))\
            .replace('gwpid', dataframe['grosswrittenpremiumtransactionidentifier'][0]) \
            .replace('ipid', str(dataframe['productidentifier'][0]))

        unearned_dataframe = pd.read_sql_query(unearned_query, scenario['connection'])
        dataframe = dataframe.merge(unearned_dataframe, how="inner", left_on=["calendarmonthidentiifer"],
            right_on=["calendarmonthidentifier"])

        dataframe['unearnedfunctional'] = -1 * dataframe['unearnedfunctional']
        dataframe['unearnedtransactional'] = -1 * dataframe['unearnedtransactional']

        sum_gross_written = scenario['sumwritten'].replace('inscont', dataframe['insurancecontractidentifier'][0])\
            .replace('gwpid', dataframe['grosswrittenpremiumtransactionidentifier'][0])
        sum_gross_written_dataframe = pd.read_sql_query(sum_gross_written, scenario['connection'])

        dataframe = dataframe.merge(sum_gross_written_dataframe, how="inner", left_on=["calendarmonthidentiifer"],
                                    right_on=["calendarmonthidentifier"])

        # dataframe.drop(['calendarmonthidentifier_x', 'calendarmonthidentifier_y'], axis=1, inplace=True)

        dataframe['sum_earnedfunctional'] = 0.00
        dataframe['sum_earnedtransactional'] = 0.00
        calc_earn_funct = 0.00
        calc_earn_trans = 0.00

        earned_query = scenario['earned'].replace('inscont',dataframe['insurancecontractidentifier'][0])\
            .replace('gwpid', dataframe['grosswrittenpremiumtransactionidentifier'][0])
        earned_dataframe = pd.read_sql_query(earned_query, scenario['connection'])

        earned_dataframe = earned_dataframe.groupby(['calendarmonthidentifier'])['grossearnedpremiumfunctionalamount','grossearnedpremiumtransactionalamount'].agg('sum')
        earned_dataframe.reset_index(level=0, inplace=True)

        earned_dataframe['sum_earnedfunctional'] = earned_dataframe.grossearnedpremiumfunctionalamount.cumsum()
        earned_dataframe['sum_earnedtransactional'] = earned_dataframe.grossearnedpremiumtransactionalamount.cumsum()

        for i in dataframe.index:
            month = dataframe['calendarmonthidentiifer'][i]
            dataframe['sum_earnedfunctional'][i] = earned_dataframe.loc[earned_dataframe['calendarmonthidentifier']==month,'sum_earnedfunctional'] + float(calc_earn_funct)
            dataframe['sum_earnedtransactional'][i] = earned_dataframe.loc[earned_dataframe['calendarmonthidentifier']==month,'sum_earnedtransactional'] + float(calc_earn_trans)

            dataframe['sum_earnedfunctional'][i] = dataframe['sum_functional_written'][i] - dataframe['sum_earnedfunctional'][i]
            calc_earn_funct = float(calc_earn_funct) + dataframe['sum_earnedfunctional'][i]
            calc_earn_funct = Decimal(str(Decimal(str(calc_earn_funct)).quantize(Decimal('0.000001'), ROUND_HALF_UP))) \
                .quantize(Decimal('0.01'), ROUND_HALF_UP)

            dataframe['sum_earnedtransactional'][i] = dataframe['sum_transactional_written'][i] - dataframe['sum_earnedtransactional'][i]
            calc_earn_trans = float(calc_earn_trans) + dataframe['sum_earnedtransactional'][i]
            calc_earn_trans = Decimal(str(Decimal(str(calc_earn_trans)).quantize(Decimal('0.000001'), ROUND_HALF_UP))) \
                .quantize(Decimal('0.01'), ROUND_HALF_UP)

        dataframe.drop(['sum_functional_written', 'sum_transactional_written'], axis=1, inplace=True)

        unearned_amount_funct = round(dataframe['unearnedfunctional'].sum(), 2)
        unearned_amount_trans = round(dataframe['unearnedtransactional'].sum(), 2)
        earned_amount_funct = round(dataframe['sum_earnedfunctional'].sum(), 2)
        earned_amount_trans = round(dataframe['sum_earnedtransactional'].sum(), 2)
    else:
        unearned_amount_funct = 0.00
        unearned_amount_trans = 0.00
        earned_amount_funct = 0.00
        earned_amount_trans = 0.00

    systransactionid = "SYSCAN" + str(dataframe['insuranceproductsurrogatekey'][0]) +\
                       str(dataframe['grosswrittenpremiumtransactionidentifier'][0])

    return unearned_amount_funct, unearned_amount_trans, earned_amount_funct, earned_amount_trans, systransactionid


def calculate_sum_of_unearned_and_earned_amounts(scenario,master_df):
    """
    Vectorised method call to calculate sum of earned and unearned premium amount for transactional and functional amount
    :param scenario: scenario
    :param master_df: master_df
    """
    master_df['sum_Automation_UEPFunctionalAmount'], master_df['sum_Automation_UEPTransactionalAmount'], \
    master_df['sum_Automation_EPFunctionalAmount'], master_df['sum_Automation_EPTransactionalAmount'], master_df['sum_Automation'],   = \
        np.vectorize(calculate_unearned_and_earned_amounts)(scenario, master_df['grosswrittenpremiumtransactionidentifier'],
                                                            master_df['transactiondate'],
                                                            master_df['onriskdate'],
                                                            master_df['offriskdate'],
                                                            master_df['insuranceproductsurrogatekey'],
                                                            master_df['productidentifier'],
                                                            master_df['grosswrittenpremiumfunctionalamount'],
                                                            master_df['grosswrittenpremiumtransactionalamount'],
                                                            master_df['start_date'],
                                                            master_df['start_range'],
                                                            master_df['end_range'],
                                                            master_df['insurancecontractidentifier'])


def test_premium_calculation(scenario, reportfolder):
    """
    Main method to compare calculated sum of earned and unearned amount with the sum of earned and unearned values in
    transformatio table and generates html reports for all record set and separate report for comparison failed records
    :param scenario: scenario
    :param reportfolder: reportfolder
    :return:master_df
    """
    master_df = pd.read_sql_query(scenario['master_df_query'], scenario['connection'])
    if len(master_df) == 0:
        print('No Cancellation Records in the batchkey')
        assert False

    master_df['onriskdate'] = pd.to_datetime(master_df['onriskdate']).dt.date
    master_df['offriskdate'] = pd.to_datetime(master_df['offriskdate']).dt.date
    master_df['transactiondate_temp'] = master_df['transactiondate']
    master_df['transactiondate'] = pd.to_datetime(master_df['transactiondate']).dt.date

    master_df['start_date'] = np.vectorize(calculate_start_date)(master_df['onriskdate'], master_df['transactiondate'])
    master_df['start_range'] = np.vectorize(calculate_start_range, otypes=[pd.DatetimeIndex])(master_df['start_date'],
                                                                                              master_df['offriskdate'])
    master_df['end_range'] = np.vectorize(calculate_end_range, otypes=[pd.DatetimeIndex])(master_df['start_date'],
                                                                                          master_df['offriskdate'])
    master_df['transactiondate'] = master_df['transactiondate_temp']

    calculate_sum_of_unearned_and_earned_amounts(scenario, master_df)

    columns = ['sum_Automation_UEPFunctionalAmount', 'sum_Automation_UEPTransactionalAmount',
               'sum_Automation_EPFunctionalAmount', 'sum_Automation_EPTransactionalAmount']

    for col in columns:
        master_df = master_df.round({col: 2})

    tn_dataframe = pd.read_sql_query(scenario['tn_df_query'], scenario['connection'])

    records = pd.merge(master_df, tn_dataframe, how='outer', left_on=['insurancecontractidentifier','sum_Automation'],
                       right_on=['insurancecontractidentifier','grosswrittenpremiumtransactionidentifier'], indicator=True)

    records['Auto_vs_tn_GEPTxAmount'] = np.where(
        records['sum_Automation_EPTransactionalAmount'] == records['tn_sum_grossearnedpremiumtransactionalamount'],
        'True', 'False')
    records['Auto_vs_tn_GEPFxAmount'] = np.where(
        records['sum_Automation_EPFunctionalAmount'] == records['tn_sum_grossearnedpremiumfunctionalamount'],
        'True', 'False')
    records['Auto_vs_tn_GUEPTxAmount'] = np.where(
        records['sum_Automation_UEPTransactionalAmount'] == records['tn_sum_grossunearnedpremiumtransactionalamount'],
        'True', 'False')
    records['Auto_vs_tn_GUEPFxAmount'] = np.where(
        records['sum_Automation_UEPFunctionalAmount'] == records['tn_sum_grossunearnedpremiumfunctionalamount'],
        'True', 'False')
    html = ".html"
    html_file = open(reportfolder + '/premiumcalculationcancellation_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + html, 'w')
    html_file.write(records.to_html(classes='w3-table-all'))
    html_file.close()


    fail_records = records.loc[(records['Auto_vs_tn_GEPTxAmount'] == 'False') |
                               (records['Auto_vs_tn_GEPFxAmount'] == 'False') |
                               (records['Auto_vs_tn_GUEPTxAmount'] == 'False') |
                               (records['Auto_vs_tn_GUEPFxAmount'] == 'False')]

    missing_df = fail_records[fail_records['_merge'] == 'left_only']
    failed_df = fail_records[fail_records['_merge'] == 'both']
    filename = reportfolder + '/FailedRecordsCancellation_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + '.xlsx'

    if not failed_df.empty:
        html_file = open(
            reportfolder + '/FailedRecordsCancellation_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + html, 'w')
        html_file.write(failed_df.to_html(classes='w3-table-all'))
        html_file.close()
    if not missing_df.empty:
        html_file = open(
            reportfolder + '/MissingRecordsCancellation_batchkey-' + scenario['batchkey'] + '_' + scenario[
                'start'] + '_' + scenario[
                'end'] + html, 'w')
        html_file.write(missing_df.to_html(classes='w3-table-all'))
        html_file.close()

    if not (failed_df.empty & missing_df.empty):
        with ExcelWriter(filename, engine="xlsxwriter") as writer:
            failed_df.to_excel(writer, index=False, sheet_name='Failed Policies')
            for column in failed_df:
                column_width = max(failed_df[column].astype(str).map(len).max(), len(column)) + 2
                col_idx = failed_df.columns.get_loc(column)
                writer.sheets['Failed Policies'].set_column(col_idx, col_idx, column_width)
            missing_df.to_excel(writer, index=False, sheet_name='Missing Policies in TN')
            for column in missing_df:
                column_width = max(missing_df[column].astype(str).map(len).max(), len(column)) + 2
                col_idx = missing_df.columns.get_loc(column)
                writer.sheets['Missing Policies in TN'].set_column(col_idx, col_idx, column_width)
        assert False
