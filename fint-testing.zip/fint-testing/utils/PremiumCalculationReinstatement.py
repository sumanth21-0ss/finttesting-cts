import pandas as pd
import numpy as np
from decimal import Decimal, ROUND_HALF_UP
from pandas import ExcelWriter
from utils.PremiumCalculation import calculate_start_date, calculate_start_range, calculate_end_range, split_records


pd.set_option('display.width', 200)
pd.set_option('display.max_columns', 10)


def calculate_unearned_and_earned_amounts_reinstatement(scenario, grosswrittenpremiumtransactionidentifier, transactiondate, onriskdate,
                                                        offriskdate, insuranceproductsurrogatekey, productidentifier,
                                                        grosswrittenpremiumfunctionalamount, grosswrittenpremiumtransactionalamount,
                                                        start_date, start_range, end_range,insurancecontractidentifier ):
    """
    multiple records are created based on start and end range
    unearned is calculated using (sum of unearned amount of the calendar month)*-1 for reinstatement records for the same insurancecontractid
    earned is calculated using (sum of GWP amount of the calendar month) - Sum of earned amount of previous calendar months
    :param scenario: scenario
    :param grosswrittenpremiumtransactionidentifier: grosswrittenpremiumtransactionidentifier
    :param insuranceproductsurrogatekey: insuranceproductsurrogatekey
    :param productidentifier: productidentifier
    :param grosswrittenpremiumfunctionalamount: grosswrittenpremiumfunctionalamount
    :param grosswrittenpremiumtransactionalamount: grosswrittenpremiumtransactionalamount
    :param start_date: start_date
    :param start_range: start_range
    :param end_range: end_range
    :param transactiondate: transactiondate
    :param onriskdate: onriskdate
    :param offriskdate: offriskdate
    :param insurancecontractidentifier: insurancecontractidentifier
    :return: unearned_amount_funct, unearned_amount_trans, earned_amount_funct, earned_amount_trans
    """
    start_len = len(start_range)
    end_len = len(end_range)
    d = {'grosswrittenpremiumtransactionidentifier': [grosswrittenpremiumtransactionidentifier],
         'insuranceproductsurrogatekey': [insuranceproductsurrogatekey],
         'productidentifier': [productidentifier],
         'grosswrittenpremiumfunctionalamount': [grosswrittenpremiumfunctionalamount],
         'grosswrittenpremiumtransactionalamount': [grosswrittenpremiumtransactionalamount],
         'start_date': [start_date],
         'start_range': [start_range],
         'end_range': [end_range],
         'transactiondate': [transactiondate],
         'onriskdate': [onriskdate],
         'offriskdate': [offriskdate],
         'insurancecontractidentifier': [insurancecontractidentifier]}

    vl_dataframe = split_records(d, start_len, end_len, onriskdate, offriskdate, start_range, end_range)

    vl_dataframe['calendarmonthidentiifer'] = vl_dataframe['Monthstart'].apply(lambda x: x.strftime('%Y%m'))

    unearned_query = scenario['unearned'].replace('inscont', vl_dataframe['insurancecontractidentifier'][0])  \
        .replace('ipid', str(vl_dataframe['insuranceproductsurrogatekey'][0])) \
        .replace('trndt', str(vl_dataframe['transactiondate'][0]))


    unearned_dataframe = pd.read_sql_query(unearned_query, scenario['connection'])
    vl_dataframe = vl_dataframe.merge(unearned_dataframe, how="inner", left_on=["calendarmonthidentiifer"],
                                      right_on=["calendarmonthidentifier"])

    vl_dataframe['unearnedfunctional'] = -1 * vl_dataframe['unearnedfunctional']
    vl_dataframe['unearnedtransactional'] = -1 * vl_dataframe['unearnedtransactional']
    vl_dataframe['earnedfunctional'] = -1 * vl_dataframe['earnedfunctional']
    vl_dataframe['earnedtransactional'] = -1 * vl_dataframe['earnedtransactional']

    unearned_amount_funct = round(vl_dataframe['unearnedfunctional'].sum(), 2)
    unearned_amount_trans = round(vl_dataframe['unearnedtransactional'].sum(), 2)
    earned_amount_funct = round(vl_dataframe['earnedfunctional'].sum(), 2)
    earned_amount_trans = round(vl_dataframe['earnedtransactional'].sum(), 2)

    systransactionid = "SYSREI" + str(vl_dataframe['insuranceproductsurrogatekey'][0]) + \
                       str(vl_dataframe['grosswrittenpremiumtransactionidentifier'][0])

    return unearned_amount_funct, unearned_amount_trans, earned_amount_funct, earned_amount_trans, systransactionid


def calculate_sum_of_unearned_and_earned_amounts_reinstatement(scenario, master_df):
    """
    Vectorised method call to calculate sum of earned and unearned premium amount for transactional and functional amount
    :param scenario: scenario
    :param master_df: master_df
    """
    master_df['sum_Automation_UEPFunctionalAmount'], master_df['sum_Automation_UEPTransactionalAmount'], \
    master_df['sum_Automation_EPFunctionalAmount'], master_df['sum_Automation_EPTransactionalAmount'], master_df['sum_Automation'],   = \
        np.vectorize(calculate_unearned_and_earned_amounts_reinstatement)(scenario, master_df['grosswrittenpremiumtransactionidentifier'],
                                                            master_df['transactiondate'],
                                                            master_df['onriskdate'],
                                                            master_df['offriskdate'],
                                                            master_df['insuranceproductsurrogatekey'],
                                                            master_df['productidentifier'],
                                                            master_df['grosswrittenpremiumfunctionalamount'],
                                                            master_df['grosswrittenpremiumtransactionalamount'],
                                                            master_df['start_date'],
                                                            master_df['start_range'],
                                                            master_df['end_range'],
                                                            master_df['insurancecontractidentifier'])


def test_premium_calculation_reinstatement(scenario, reportfolder):
    """
    Main method to compare calculated sum of earned and unearned amount with the sum of earned and unearned values in
    transformatio table and generates html reports for all record set and separate report for comparison failed records_reinstate
    :param scenario: scenario
    :param reportfolder: reportfolder
    :return:master_df
    """
    master_df = pd.read_sql_query(scenario['master_df_query'], scenario['connection'])
    if len(master_df) == 0:
        print('No Reinstatement Records in the batchkey')
        assert False

    master_df['onriskdate'] = pd.to_datetime(master_df['onriskdate']).dt.date
    master_df['offriskdate'] = pd.to_datetime(master_df['offriskdate']).dt.date
    master_df['transactiondate_temp'] = master_df['transactiondate']
    master_df['transactiondate'] = pd.to_datetime(master_df['transactiondate']).dt.date

    master_df['start_date'] = np.vectorize(calculate_start_date)(master_df['onriskdate'], master_df['transactiondate'])
    master_df['start_range'] = np.vectorize(calculate_start_range, otypes=[pd.DatetimeIndex])(master_df['start_date'],
                                                                                              master_df['offriskdate'])
    master_df['end_range'] = np.vectorize(calculate_end_range, otypes=[pd.DatetimeIndex])(master_df['start_date'],
                                                                                          master_df['offriskdate'])
    master_df['transactiondate'] = master_df['transactiondate_temp']

    calculate_sum_of_unearned_and_earned_amounts_reinstatement(scenario, master_df)

    columns = ['sum_Automation_UEPFunctionalAmount', 'sum_Automation_UEPTransactionalAmount',
               'sum_Automation_EPFunctionalAmount', 'sum_Automation_EPTransactionalAmount']

    for col in columns:
        master_df = master_df.round({col: 2})

    tn_dataframe = pd.read_sql_query(scenario['tn_df_query'], scenario['connection'])

    records_reinstate = pd.merge(master_df, tn_dataframe, how='outer', left_on=['insurancecontractidentifier','sum_Automation'],
                       right_on=['insurancecontractidentifier','grosswrittenpremiumtransactionidentifier'], indicator=True)

    records_reinstate['Auto_vs_tn_GEPTxAmount'] = np.where(
        records_reinstate['sum_Automation_EPTransactionalAmount'] == records_reinstate['tn_sum_grossearnedpremiumtransactionalamount'],
        'True', 'False')
    records_reinstate['Auto_vs_tn_GEPFxAmount'] = np.where(
        records_reinstate['sum_Automation_EPFunctionalAmount'] == records_reinstate['tn_sum_grossearnedpremiumfunctionalamount'],
        'True', 'False')
    records_reinstate['Auto_vs_tn_GUEPTxAmount'] = np.where(
        records_reinstate['sum_Automation_UEPTransactionalAmount'] == records_reinstate['tn_sum_grossunearnedpremiumtransactionalamount'],
        'True', 'False')
    records_reinstate['Auto_vs_tn_GUEPFxAmount'] = np.where(
        records_reinstate['sum_Automation_UEPFunctionalAmount'] == records_reinstate['tn_sum_grossunearnedpremiumfunctionalamount'],
        'True', 'False')
    html = ".html"
    html_file = open(reportfolder + '/premiumcalculationreinstatement_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + html, 'w')
    html_file.write(records_reinstate.to_html(classes='w3-table-all'))
    html_file.close()


    fail_records_reinstate = records_reinstate.loc[(records_reinstate['Auto_vs_tn_GEPTxAmount'] == 'False') |
                               (records_reinstate['Auto_vs_tn_GEPFxAmount'] == 'False') |
                               (records_reinstate['Auto_vs_tn_GUEPTxAmount'] == 'False') |
                               (records_reinstate['Auto_vs_tn_GUEPFxAmount'] == 'False')]

    missing_df_reinstate = fail_records_reinstate[fail_records_reinstate['_merge'] == 'left_only']
    failed_df_reinstate = fail_records_reinstate[fail_records_reinstate['_merge'] == 'both']
    filename_reinstate = reportfolder + '/FailedRecordsreinstatement_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + '.xlsx'

    if not failed_df_reinstate.empty:
        html_file = open(
            reportfolder + '/FailedRecordsreinstatement_batchkey-' + scenario['batchkey'] + '_' + scenario['start'] + '_' + scenario[
                'end'] + html, 'w')
        html_file.write(failed_df_reinstate.to_html(classes='w3-table-all'))
        html_file.close()
    if not missing_df_reinstate.empty:
        html_file = open(
            reportfolder + '/MissingRecordsreinstatement_batchkey-' + scenario['batchkey'] + '_' + scenario[
                'start'] + '_' + scenario[
                'end'] + html, 'w')
        html_file.write(missing_df_reinstate.to_html(classes='w3-table-all'))
        html_file.close()

    if not (failed_df_reinstate.empty & missing_df_reinstate.empty):
        with ExcelWriter(filename_reinstate, engine="xlsxwriter") as writer:
            failed_df_reinstate.to_excel(writer, index=False, sheet_name='Failed Policies')
            for column in failed_df_reinstate:
                column_width = max(failed_df_reinstate[column].astype(str).map(len).max(), len(column)) + 2
                col_idx = failed_df_reinstate.columns.get_loc(column)
                writer.sheets['Failed Policies'].set_column(col_idx, col_idx, column_width)
            missing_df_reinstate.to_excel(writer, index=False, sheet_name='Missing Policies in TN')
            for column in missing_df_reinstate:
                column_width = max(missing_df_reinstate[column].astype(str).map(len).max(), len(column)) + 2
                col_idx = missing_df_reinstate.columns.get_loc(column)
                writer.sheets['Missing Policies in TN'].set_column(col_idx, col_idx, column_width)
        assert False
