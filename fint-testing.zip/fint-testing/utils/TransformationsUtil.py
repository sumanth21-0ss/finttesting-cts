import pandas as pd


def date_transformation(df, column):
    """
    transform the date format of values in the specified column
    :param df: actual dataframe
    :param column: column, whose values are to be transformed
    :return: transformed dataframe
    """
    df[column] = pd.to_datetime(df[column])
    df[column] = df[column].dt.strftime("%m/%d/%y")
    return df


def date_transformation1(df, column):
    """
    transform the date format of values in the specified column
    :param df: actual dataframe
    :param column: column, whose values are to be transformed
    :return: transformed dataframe
    """
    df[column] = pd.to_datetime(df[column])
    df[column] = df[column].dt.strftime("%d/%m/%y")
    return df
